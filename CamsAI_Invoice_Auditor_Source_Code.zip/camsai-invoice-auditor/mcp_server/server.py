"""
CamsAI MCP Server — FastAPI application exposing all 5 APIs.

API 1: GET  /api/v1/payloads/{invoice_number}  — Fetch Invoice Payload
API 2: POST /api/v1/vector/query               — Vector Knowledge (ChromaDB)
API 3: POST /api/v1/policy/check              — Policy Compliance Check
API 4: POST /api/v1/ledger/write              — Ledger Write (PostgreSQL)
API 5: POST /api/v1/notify/alert              — Notification / Alert (Email)

Internal:
  POST /api/v1/payloads/seed    — Seeder endpoint
  GET  /health                  — Docker healthcheck
  GET  /api/v1/invoices         — List ledger entries
  GET  /api/v1/payloads         — List seeded payloads
"""
from __future__ import annotations

import json
import logging
import os
import smtplib
import uuid
from contextlib import asynccontextmanager
from datetime import datetime
from decimal import Decimal
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText

import asyncpg
import chromadb
from fastapi import FastAPI, HTTPException
from pydantic import BaseModel

import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).parent.parent))
from mock_data.schemas import (
    InvoiceStatus, LedgerWriteRequest, LedgerWriteResponse,
    NotificationRequest, NotificationResponse, OrchestratorState
)

logging.basicConfig(
    level=os.getenv("LOG_LEVEL", "INFO"),
    format="%(asctime)s [MCP] %(levelname)s %(name)s — %(message)s"
)
log = logging.getLogger(__name__)

# ── Config ────────────────────────────────────────────────────────────────────
DATABASE_URL = os.getenv("DATABASE_URL", "postgresql://auditor:auditor_secret@localhost:5432/invoice_ledger")
CHROMA_HOST  = os.getenv("CHROMA_HOST", "localhost")
CHROMA_PORT  = int(os.getenv("CHROMA_PORT", "8000"))
SMTP_HOST    = os.getenv("SMTP_HOST", "smtp.gmail.com")
SMTP_PORT    = int(os.getenv("SMTP_PORT", "587"))
SMTP_USER    = os.getenv("SMTP_USER", "")
SMTP_PASS    = os.getenv("SMTP_PASS", "")
ALERT_EMAIL  = os.getenv("ALERT_EMAIL", "test@example.com")

# In-memory cache backed by PostgreSQL
_payload_store: dict[str, dict] = {}
_db_pool: asyncpg.Pool | None = None
_chroma: chromadb.HttpClient | None = None

POLICY_MAX_UNIT_RATE = Decimal("4000.00")
POLICY_MAX_TOTAL     = Decimal("50000.00")


# ── Helpers ───────────────────────────────────────────────────────────────────
def _json(obj):
    if isinstance(obj, Decimal):
        return float(obj)
    raise TypeError(f"Not serializable: {type(obj)}")


# ── Lifespan ──────────────────────────────────────────────────────────────────
@asynccontextmanager
async def lifespan(app: FastAPI):
    global _db_pool, _chroma, _payload_store
    dsn = DATABASE_URL.replace("postgresql+asyncpg://", "postgresql://")
    _db_pool = await asyncpg.create_pool(dsn, min_size=2, max_size=10)
    log.info("✓ PostgreSQL pool ready")

    # Restore payloads that survived a restart
    try:
        async with _db_pool.acquire() as conn:
            rows = await conn.fetch("SELECT invoice_number, payload FROM invoice_payloads")
            for row in rows:
                _payload_store[row["invoice_number"]] = json.loads(row["payload"])
            if _payload_store:
                log.info(f"✓ Restored {len(_payload_store)} payloads from PostgreSQL")
    except Exception as e:
        log.warning(f"Could not restore payloads: {e}")

    _chroma = chromadb.HttpClient(host=CHROMA_HOST, port=CHROMA_PORT)
    log.info("✓ ChromaDB client ready")
    yield
    await _db_pool.close()


app = FastAPI(title="CamsAI Invoice Auditor — MCP Server", version="1.0.0", lifespan=lifespan)


# ── Health ────────────────────────────────────────────────────────────────────
@app.get("/health")
async def health():
    return {"status": "ok", "payloads_loaded": len(_payload_store)}


# ── Seeder endpoint ───────────────────────────────────────────────────────────
class SeedRequest(BaseModel):
    payload: dict
    scenario: str


@app.post("/api/v1/payloads/seed", status_code=201)
async def seed_payload(req: SeedRequest):
    inv_num = req.payload.get("invoice_number", f"INV-{uuid.uuid4().hex[:8].upper()}")
    _payload_store[inv_num] = req.payload

    # Persist to PostgreSQL so payloads survive MCP server restarts
    payload_json = json.dumps(req.payload, default=_json)
    async with _db_pool.acquire() as conn:
        await conn.execute(
            """
            INSERT INTO invoice_payloads (invoice_number, scenario, payload)
            VALUES ($1, $2, $3::jsonb)
            ON CONFLICT (invoice_number) DO UPDATE
                SET payload = EXCLUDED.payload, scenario = EXCLUDED.scenario
            """,
            inv_num, req.scenario, payload_json
        )
    log.info(f"[SEED] Stored {inv_num} (scenario {req.scenario})")
    return {"stored": inv_num, "scenario": req.scenario}


# ── API 1 — Fetch Payload ─────────────────────────────────────────────────────
@app.get("/api/v1/payloads")
async def list_payloads():
    return {"invoices": list(_payload_store.keys()), "count": len(_payload_store)}


@app.get("/api/v1/payloads/{invoice_number}")
async def fetch_payload(invoice_number: str):
    if invoice_number not in _payload_store:
        raise HTTPException(status_code=404, detail=f"Invoice {invoice_number} not found")
    log.info(f"[API1] Fetched payload: {invoice_number}")
    return {"invoice_number": invoice_number, "payload": _payload_store[invoice_number]}


# ── API 2 — Vector Knowledge Base ─────────────────────────────────────────────
class VectorQueryRequest(BaseModel):
    vendor_id: str
    vendor_name: str
    service_categories: list[str] = []
    n_results: int = 3


@app.post("/api/v1/vector/query")
async def vector_query(req: VectorQueryRequest):
    query_text = (
        f"Vendor: {req.vendor_name} (ID: {req.vendor_id}). "
        f"Services: {', '.join(req.service_categories) or 'general'}. "
        f"Retrieve contract terms including max unit rate and billing limits."
    )
    try:
        # Gracefully handle missing collection (seeder may not have run yet)
        try:
            collection = _chroma.get_collection("vendor_contracts")
        except Exception:
            log.warning("[API2] vendor_contracts collection not found — returning empty")
            return {"vendor_id": req.vendor_id, "contracts": [], "warning": "Collection not seeded yet"}
        count = collection.count()
        if count == 0:
            return {"vendor_id": req.vendor_id, "contracts": []}
        results = collection.query(
            query_texts=[query_text],
            n_results=min(req.n_results, count)
        )
        contracts = []
        if results and results["metadatas"]:
            for meta, doc, dist in zip(
                results["metadatas"][0],
                results["documents"][0],
                results["distances"][0]
            ):
                contracts.append({
                    "vendor_id":     meta.get("vendor_id"),
                    "vendor_name":   meta.get("vendor_name"),
                    "max_unit_rate": meta.get("max_unit_rate"),
                    "max_total":     meta.get("max_total"),
                    "valid_from":    meta.get("valid_from"),
                    "valid_to":      meta.get("valid_to"),
                    "contract_text": doc,
                    "similarity":    round(1 - dist, 4)
                })
        log.info(f"[API2] Vector query for {req.vendor_id}: {len(contracts)} contracts")
        return {"vendor_id": req.vendor_id, "contracts": contracts}
    except Exception as e:
        log.error(f"[API2] ChromaDB error: {e}")
        return {"vendor_id": req.vendor_id, "contracts": [], "error": str(e)}


# ── API 3 — Policy Check ──────────────────────────────────────────────────────
class PolicyCheckRequest(BaseModel):
    invoice: dict
    contracts: list[dict] = []


@app.post("/api/v1/policy/check")
async def policy_check(req: PolicyCheckRequest):
    flags = []
    violations = []
    score = 100.0

    try:
        invoice_data  = req.invoice
        line_items    = invoice_data.get("line_items", [])
        total_amount  = Decimal(str(invoice_data.get("total_amount", 0)))
        vendor_id     = invoice_data.get("vendor", {}).get("vendor_id", "")

        contract_max_unit  = POLICY_MAX_UNIT_RATE
        contract_max_total = POLICY_MAX_TOTAL
        vector_match_score = None

        if req.contracts:
            best = req.contracts[0]
            if best.get("vendor_id") == vendor_id and best.get("max_unit_rate"):
                contract_max_unit  = Decimal(str(best["max_unit_rate"]))
                contract_max_total = Decimal(str(best.get("max_total", 50000)))
                vector_match_score = best.get("similarity")

        # Rule 1: empty line items
        if not line_items:
            flags.append({"field": "line_items", "reason": "Invoice has no line items",
                          "severity": "critical", "value": []})
            violations.append("EMPTY_LINE_ITEMS")
            score -= 50.0

        # Rule 2: unit rate per line item
        for item in line_items:
            rate = Decimal(str(item.get("unit_rate", 0)))
            if rate > contract_max_unit:
                flags.append({
                    "field": f"line_items[{item.get('description', 'unknown')}].unit_rate",
                    "reason": f"Unit rate ${rate} exceeds contract threshold ${contract_max_unit}",
                    "severity": "high",
                    "value": float(rate)
                })
                violations.append(f"UNIT_RATE_EXCEEDED:{item.get('description')}")
                score -= 30.0

        # Rule 3: total amount limit
        if total_amount > contract_max_total:
            flags.append({
                "field": "total_amount",
                "reason": f"Total ${total_amount} exceeds maximum ${contract_max_total}",
                "severity": "high",
                "value": float(total_amount)
            })
            violations.append("TOTAL_EXCEEDS_LIMIT")
            score -= 20.0

        # Rule 4: negative values
        if total_amount < 0:
            flags.append({"field": "total_amount", "reason": "Total amount is negative",
                          "severity": "critical", "value": float(total_amount)})
            violations.append("NEGATIVE_TOTAL")
            score -= 50.0

        # Rule 5: line item sum mismatch
        if line_items:
            computed = sum(Decimal(str(i.get("total", 0))) for i in line_items)
            if abs(computed - total_amount) > Decimal("0.01"):
                flags.append({
                    "field": "total_amount",
                    "reason": f"Sum of line items ${computed} != invoice total ${total_amount}",
                    "severity": "medium",
                    "value": float(computed)
                })
                violations.append("LINE_ITEM_SUM_MISMATCH")
                score -= 15.0

        score  = max(0.0, min(100.0, score))
        passed = len(violations) == 0

        log.info(f"[API3] Policy check for {vendor_id}: passed={passed} score={score:.1f} flags={len(flags)}")
        return {
            "passed":             passed,
            "compliance_score":   round(score, 2),
            "anomaly_flags":      flags,
            "policy_violations":  violations,
            "vector_match_score": vector_match_score,
            "recommendation":     "APPROVE" if passed else ("ESCALATE" if score < 50 else "FLAG_FOR_REVIEW")
        }
    except Exception as e:
        log.error(f"[API3] Policy check error: {e}")
        raise HTTPException(status_code=500, detail=str(e))


# ── API 4 — Ledger Write ──────────────────────────────────────────────────────
@app.post("/api/v1/ledger/write")
async def ledger_write(req: LedgerWriteRequest):
    try:
        invoice = req.invoice
        val     = req.validation
        inv_id  = str(uuid.uuid4())
        status  = InvoiceStatus.APPROVED if val.passed else InvoiceStatus.FLAGGED

        async with _db_pool.acquire() as conn:
            # Use RETURNING to get the actual stored ID (handles ON CONFLICT upsert)
            row = await conn.fetchrow(
                """
                INSERT INTO invoices
                    (id, invoice_number, vendor_id, vendor_name, invoice_date, due_date,
                     currency, total_amount, status, compliance_score, anomaly_flags, raw_payload)
                VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11::jsonb,$12::jsonb)
                ON CONFLICT (invoice_number) DO UPDATE
                    SET status=EXCLUDED.status,
                        compliance_score=EXCLUDED.compliance_score,
                        anomaly_flags=EXCLUDED.anomaly_flags,
                        updated_at=NOW()
                RETURNING id
                """,
                inv_id,
                invoice.invoice_number,
                invoice.vendor.vendor_id,
                invoice.vendor.vendor_name,
                invoice.invoice_date,
                invoice.due_date,
                invoice.currency,
                float(invoice.total_amount),
                status.value,
                val.compliance_score,
                json.dumps([f.model_dump() for f in val.anomaly_flags]),
                json.dumps(invoice.model_dump(mode="json"), default=_json)
            )

            # Use actual DB id (from RETURNING) for FK references
            actual_id = str(row["id"]) if row else inv_id
            # Delete existing line items (handles re-run / upsert)
            await conn.execute("DELETE FROM line_items WHERE invoice_id = $1", actual_id)
            for item in invoice.line_items:
                await conn.execute(
                    """
                    INSERT INTO line_items
                        (id, invoice_id, description, quantity, unit_rate, total, category)
                    VALUES ($1,$2,$3,$4,$5,$6,$7)
                    """,
                    str(uuid.uuid4()), actual_id,
                    item.description, float(item.quantity),
                    float(item.unit_rate), float(item.total), item.category
                )

            await conn.execute(
                """
                INSERT INTO audit_events (id, invoice_id, agent, state, event_type, payload)
                VALUES ($1,$2,$3,$4,$5,$6::jsonb)
                """,
                str(uuid.uuid4()), actual_id, "Agent3-Settlement",
                req.orchestrator_state.value, "LEDGER_WRITE",
                json.dumps({"status": status.value, "compliance_score": val.compliance_score})
            )

        log.info(f"[API4] Ledger write: {invoice.invoice_number} → {status.value}")
        return LedgerWriteResponse(
            success=True,
            invoice_id=actual_id,
            message=f"Invoice {invoice.invoice_number} written to ledger with status {status.value}"
        )
    except Exception as e:
        log.error(f"[API4] Ledger write error: {e}")
        raise HTTPException(status_code=500, detail=str(e))


# ── API 5 — Notification / Alert ─────────────────────────────────────────────
@app.post("/api/v1/notify/alert")
async def notify_alert(req: NotificationRequest):
    try:
        flags_html = "".join(
            f"<li><b>{f.field}</b>: {f.reason} (severity: {f.severity})</li>"
            for f in req.anomaly_flags
        ) or "<li>No specific flags</li>"

        html_body = f"""
        <html><body style="font-family:Arial,sans-serif;color:#333;">
        <h2 style="color:#c0392b;">⚠️ Invoice Anomaly Alert</h2>
        <table style="border-collapse:collapse;width:100%;">
            <tr><td style="padding:8px;border:1px solid #ddd;"><b>Invoice #</b></td>
                <td style="padding:8px;border:1px solid #ddd;">{req.invoice_number}</td></tr>
            <tr><td style="padding:8px;border:1px solid #ddd;"><b>Vendor</b></td>
                <td style="padding:8px;border:1px solid #ddd;">{req.vendor_name}</td></tr>
            <tr><td style="padding:8px;border:1px solid #ddd;"><b>Total Amount</b></td>
                <td style="padding:8px;border:1px solid #ddd;">${req.total_amount:,.2f}</td></tr>
            <tr><td style="padding:8px;border:1px solid #ddd;"><b>Severity</b></td>
                <td style="padding:8px;border:1px solid #ddd;color:#c0392b;">{req.severity.upper()}</td></tr>
            <tr><td style="padding:8px;border:1px solid #ddd;"><b>State</b></td>
                <td style="padding:8px;border:1px solid #ddd;">{req.orchestrator_state.value}</td></tr>
        </table>
        <h3>Anomaly Flags:</h3><ul>{flags_html}</ul>
        <p style="color:#888;font-size:12px;">
            CamsAI Invoice Auditor — {datetime.utcnow().isoformat()} UTC
        </p></body></html>
        """

        message_id = f"alert-{uuid.uuid4().hex[:12]}"

        if SMTP_USER and SMTP_PASS and "@" in SMTP_USER:
            try:
                msg = MIMEMultipart("alternative")
                msg["Subject"] = f"[INVOICE ALERT] {req.invoice_number} — {req.severity.upper()}"
                msg["From"]    = SMTP_USER
                msg["To"]      = req.recipient_email
                msg.attach(MIMEText(html_body, "html"))
                with smtplib.SMTP(SMTP_HOST, SMTP_PORT) as server:
                    server.ehlo()
                    server.starttls()
                    server.login(SMTP_USER, SMTP_PASS)
                    server.sendmail(SMTP_USER, req.recipient_email, msg.as_string())
                log.info(f"[API5] Email sent to {req.recipient_email}: {message_id}")
                return NotificationResponse(sent=True, channel="email", message_id=message_id)
            except smtplib.SMTPException as smtp_err:
                log.warning(f"[API5] SMTP failed: {smtp_err} — falling back to log")

        # Log-only fallback (fully functional for demo/testing)
        log.warning(
            f"\n{'='*60}\n"
            f"  📧 ALERT NOTIFICATION (log-only mode)\n"
            f"  To      : {req.recipient_email}\n"
            f"  Invoice : {req.invoice_number}  Vendor: {req.vendor_name}\n"
            f"  Amount  : ${req.total_amount:,.2f}  Severity: {req.severity.upper()}\n"
            f"  Flags   : {len(req.anomaly_flags)}\n"
            f"  Msg ID  : {message_id}\n"
            f"{'='*60}"
        )
        return NotificationResponse(sent=True, channel="log", message_id=message_id)

    except Exception as e:
        log.error(f"[API5] Notification error: {e}")
        return NotificationResponse(sent=False, channel="email", error=str(e))


# ── Dashboard ─────────────────────────────────────────────────────────────────
@app.get("/api/v1/invoices")
async def list_invoices():
    async with _db_pool.acquire() as conn:
        rows = await conn.fetch("""
            SELECT invoice_number, vendor_name, total_amount, status,
                   compliance_score, created_at
            FROM invoices ORDER BY created_at DESC LIMIT 50
        """)
    return {"invoices": [dict(r) for r in rows]}
