"""
Unit tests — no external dependencies required.
Run: pytest tests/test_unit.py -v
"""
from __future__ import annotations

import pytest
from decimal import Decimal
from datetime import date

import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).parent.parent))

from mock_data.schemas import (
    GraphState, InvoicePayload, LineItem, OrchestratorState, VendorInfo, ValidationResult, AnomalyFlag
)
from mock_data.seeder import scenario_a, scenario_b, scenario_c_raw
from agents.agent1_ingestion import _parse_raw_to_invoice, _coerce_decimal


# ──────────────────────────────────────────────────────────────────────────────
# Decimal coercion
# ──────────────────────────────────────────────────────────────────────────────

def test_coerce_decimal_normal():
    assert _coerce_decimal("1234.56") == Decimal("1234.56")

def test_coerce_decimal_currency_string():
    assert _coerce_decimal("$1,234.56") == Decimal("1234.56")

def test_coerce_decimal_none():
    assert _coerce_decimal(None) == Decimal("0")

def test_coerce_decimal_negative():
    assert _coerce_decimal("-500") == Decimal("-500")


# ──────────────────────────────────────────────────────────────────────────────
# Scenario generation
# ──────────────────────────────────────────────────────────────────────────────

def test_scenario_a_valid():
    inv = scenario_a()
    assert inv.total_amount == Decimal("4000.00")
    assert inv.scenario == "A"
    assert len(inv.line_items) == 4
    for item in inv.line_items:
        assert item.unit_rate <= Decimal("4000.00")

def test_scenario_b_has_violation():
    inv = scenario_b()
    assert inv.scenario == "B"
    # Software License line item has unit_rate $15,000 — exceeds threshold
    flagged = [i for i in inv.line_items if i.unit_rate > Decimal("4000.00")]
    assert len(flagged) >= 1

def test_scenario_c_is_malformed():
    raw = scenario_c_raw()
    assert raw["total_amount"] < 0          # negative
    assert raw["line_items"] == []           # empty
    assert raw["vendor"]["vendor_name"] is None  # null name
    # Should raise when parsed strictly
    with pytest.raises(Exception):
        InvoicePayload(**raw)


# ──────────────────────────────────────────────────────────────────────────────
# Extraction parsing
# ──────────────────────────────────────────────────────────────────────────────

def test_parse_scenario_a_raw():
    inv = scenario_a()
    raw = inv.model_dump(mode="json")
    parsed = _parse_raw_to_invoice(raw)
    assert parsed.invoice_number == "INV-SCENARIO-A"
    assert parsed.total_amount == Decimal("4000.00")
    assert len(parsed.line_items) == 4

def test_parse_ocr_style_payload():
    """Test parsing a loosely structured OCR-like payload."""
    raw = {
        "invoice_number": "INV-OCR-001",
        "vendor": {"vendor_id": "V-99", "vendor_name": "OCR Vendor"},
        "invoice_date": "2024-03-15",
        "currency": "USD",
        "line_items": [
            {"description": "Consulting", "quantity": "10", "unit_rate": "200.00",
             "total": "2000.00", "category": "consulting"},
        ],
        "total_amount": "2000.00",
    }
    parsed = _parse_raw_to_invoice(raw)
    assert parsed.vendor.vendor_id == "V-99"
    assert parsed.total_amount == Decimal("2000.00")


# ──────────────────────────────────────────────────────────────────────────────
# GraphState routing logic
# ──────────────────────────────────────────────────────────────────────────────

def test_graph_state_defaults():
    gs = GraphState(invoice_number="INV-TEST")
    assert gs.orchestrator_state == OrchestratorState.INGESTING
    assert gs.retry_count == 0
    assert gs.max_retries == 3

def test_graph_state_error_transition():
    gs = GraphState(
        invoice_number="INV-X",
        orchestrator_state=OrchestratorState.ERROR,
        extraction_error="connection error to API"
    )
    from agents.orchestrator import route_after_ingest, _is_transient
    assert _is_transient(gs.extraction_error) is True


# ──────────────────────────────────────────────────────────────────────────────
# Validation result
# ──────────────────────────────────────────────────────────────────────────────

def test_validation_result_passed():
    vr = ValidationResult(
        passed=True,
        compliance_score=100.0,
        recommendation="APPROVE"
    )
    assert vr.passed is True
    assert vr.anomaly_flags == []

def test_validation_result_flagged():
    flag = AnomalyFlag(
        field="line_items[Software License].unit_rate",
        reason="Unit rate $15000 exceeds threshold $4000",
        severity="high",
        value=15000.0
    )
    vr = ValidationResult(
        passed=False,
        compliance_score=70.0,
        anomaly_flags=[flag],
        policy_violations=["UNIT_RATE_EXCEEDED:Software License"],
        recommendation="ESCALATE"
    )
    assert vr.passed is False
    assert len(vr.anomaly_flags) == 1
    assert vr.anomaly_flags[0].severity == "high"


# ──────────────────────────────────────────────────────────────────────────────
# OCR pipeline tests
# ──────────────────────────────────────────────────────────────────────────────

def test_ocr_benchmark_scorer_exact_match():
    from agents.agent1_ingestion import _score_ocr_vs_ground_truth
    extracted = {"invoice_number": "INV-001", "total_amount": "1234.56", "invoice_date": "2024-03-15"}
    gt = {"gt_parse": {"invoice_number": "INV-001", "total_amount": "1234.56", "invoice_date": "2024-03-15"}}
    score = _score_ocr_vs_ground_truth(extracted, gt)
    assert score["overall_accuracy_pct"] == 100.0
    assert score["invoice_number"]["match"] is True


def test_ocr_benchmark_scorer_amount_tolerance():
    from agents.agent1_ingestion import _score_ocr_vs_ground_truth
    # $1,234.56 vs 1234.56 — should match (strips currency/comma)
    extracted = {"invoice_number": "X", "total_amount": "$1,234.56", "invoice_date": "2024-01-01"}
    gt = {"invoice_number": "X", "total_amount": "1234.56", "invoice_date": "2024-01-01"}
    score = _score_ocr_vs_ground_truth(extracted, gt)
    assert score["total_amount"]["match"] is True


def test_ocr_benchmark_scorer_partial_mismatch():
    from agents.agent1_ingestion import _score_ocr_vs_ground_truth
    extracted = {"invoice_number": "WRONG", "total_amount": "999.00", "invoice_date": "2024-01-01"}
    gt = {"invoice_number": "INV-001", "total_amount": "1234.56", "invoice_date": "2024-01-01"}
    score = _score_ocr_vs_ground_truth(extracted, gt)
    assert score["overall_accuracy_pct"] < 100.0
    assert score["invoice_number"]["match"] is False
    assert score["total_amount"]["match"] is False


def test_hf_invoice_number_routing():
    """HF: prefix should route to OCR path (not structured path)."""
    inv_num = "HF:mychen76:5"
    assert inv_num.startswith("HF:")
    parts = inv_num.split(":")
    assert parts[1] == "mychen76"
    assert int(parts[2]) == 5


def test_hf_dataset_registry():
    from agents.agent1_ingestion import HF_DATASETS
    assert "voxel51" in HF_DATASETS
    assert "mychen76" in HF_DATASETS
    assert HF_DATASETS["voxel51"]["hf_id"] == "Voxel51/high-quality-invoice-images-for-ocr"
    assert HF_DATASETS["mychen76"]["type"] == "image_with_ground_truth"


def test_parse_ocr_output_shape():
    """Parse a dict shaped like Claude Vision OCR output."""
    ocr_output = {
        "invoice_number": "OCR-ACM-2024-03",
        "vendor": {
            "vendor_id": "AUTO-ACMECL",
            "vendor_name": "Acme Cloud Ltd",
            "contact_email": None,
            "address": "1 Tech Lane, SF, CA"
        },
        "invoice_date": "2024-03-01",
        "due_date": None,
        "currency": "USD",
        "line_items": [
            {"description": "Cloud Compute", "quantity": 720, "unit_rate": 3.50, "total": 2520.00, "category": "compute"},
            {"description": "Storage 500GB", "quantity": 500, "unit_rate": 2.00, "total": 1000.00, "category": "storage"},
        ],
        "total_amount": 3520.00,
        "notes": None
    }
    from agents.agent1_ingestion import _parse_raw_to_invoice
    invoice = _parse_raw_to_invoice(ocr_output)
    assert invoice.invoice_number == "OCR-ACM-2024-03"
    assert invoice.vendor.vendor_name == "Acme Cloud Ltd"
    assert len(invoice.line_items) == 2
    assert float(invoice.total_amount) == 3520.00
