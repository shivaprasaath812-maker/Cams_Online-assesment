"""
Comprehensive test suite — covers every failure point seen in production.
Run: pytest tests/test_comprehensive.py -v
"""
from __future__ import annotations

import asyncio
import json
import sys
import uuid
from datetime import date, timedelta
from decimal import Decimal
from pathlib import Path
from unittest.mock import AsyncMock, MagicMock, patch

import pytest

sys.path.insert(0, str(Path(__file__).parent.parent))

from mock_data.schemas import (
    AnomalyFlag, GraphState, InvoicePayload, InvoiceStatus,
    LedgerWriteResponse, LineItem, NotificationResponse,
    OrchestratorState, ValidationResult, VendorInfo
)
from mock_data.seeder import (
    CONTRACTS, scenario_a, scenario_b, scenario_c_raw
)
from agents.agent1_ingestion import (
    _coerce_decimal, _parse_raw_to_invoice,
    _score_ocr_vs_ground_truth, HF_DATASETS
)
from agents.orchestrator import (
    _is_transient, route_after_ingest,
    route_after_validate, route_after_settle
)


# ══════════════════════════════════════════════════════════════════════════════
# 1. Schema & GraphState tests
# ══════════════════════════════════════════════════════════════════════════════

class TestGraphState:
    def test_error_fields_default_to_empty_string(self):
        gs = GraphState(invoice_number="TEST")
        assert gs.extraction_error == ""
        assert gs.validation_error == ""
        assert gs.settlement_error == ""

    def test_none_coerced_to_empty_string(self):
        gs = GraphState(
            invoice_number="TEST",
            extraction_error=None,
            validation_error=None,
            settlement_error=None
        )
        assert gs.extraction_error == ""
        assert gs.validation_error == ""
        assert gs.settlement_error == ""

    def test_error_fields_safe_to_slice(self):
        gs = GraphState(invoice_number="TEST", extraction_error=None)
        # This was the crash — must never raise TypeError
        result = gs.extraction_error[:50]
        assert result == ""

    def test_error_fields_safe_to_format(self):
        gs = GraphState(invoice_number="TEST", extraction_error=None)
        result = f"ERROR: {gs.extraction_error[:50]}"
        assert result == "ERROR: "

    def test_default_state_is_ingesting(self):
        gs = GraphState(invoice_number="TEST")
        assert gs.orchestrator_state == OrchestratorState.INGESTING

    def test_retry_count_defaults(self):
        gs = GraphState(invoice_number="TEST")
        assert gs.retry_count == 0
        assert gs.max_retries == 3

    def test_serialization_roundtrip(self):
        gs = GraphState(
            invoice_number="INV-TEST",
            orchestrator_state=OrchestratorState.VALIDATING,
            extraction_error="some error"
        )
        d = gs.model_dump()
        gs2 = GraphState(**d)
        assert gs2.invoice_number == "INV-TEST"
        assert gs2.extraction_error == "some error"


# ══════════════════════════════════════════════════════════════════════════════
# 2. Decimal coercion tests
# ══════════════════════════════════════════════════════════════════════════════

class TestDecimalCoercion:
    def test_normal_number(self):
        assert _coerce_decimal("1234.56") == Decimal("1234.56")

    def test_currency_symbol(self):
        assert _coerce_decimal("$1234.56") == Decimal("1234.56")

    def test_commas(self):
        assert _coerce_decimal("$1,234.56") == Decimal("1234.56")

    def test_none_returns_zero(self):
        assert _coerce_decimal(None) == Decimal("0")

    def test_empty_string_returns_zero(self):
        assert _coerce_decimal("") == Decimal("0")

    def test_negative(self):
        assert _coerce_decimal("-9999.99") == Decimal("-9999.99")

    def test_integer(self):
        assert _coerce_decimal(100) == Decimal("100")

    def test_float(self):
        assert _coerce_decimal(3.50) == Decimal("3.5")

    def test_invalid_string_returns_zero(self):
        assert _coerce_decimal("not-a-number") == Decimal("0")

    def test_large_amount(self):
        assert _coerce_decimal("$50,000.00") == Decimal("50000.00")


# ══════════════════════════════════════════════════════════════════════════════
# 3. Contract UUID tests
# ══════════════════════════════════════════════════════════════════════════════

class TestContractUUIDs:
    def test_all_contract_ids_are_valid_uuids(self):
        for c in CONTRACTS:
            try:
                uuid.UUID(c["id"])
            except ValueError:
                pytest.fail(f"Invalid UUID: {c['id']}")

    def test_all_contract_ids_correct_length(self):
        for c in CONTRACTS:
            assert 32 <= len(c["id"].replace("-", "")) <= 32

    def test_contract_ids_are_unique(self):
        ids = [c["id"] for c in CONTRACTS]
        assert len(ids) == len(set(ids))

    def test_contract_dates_are_strings(self):
        for c in CONTRACTS:
            assert isinstance(c["valid_from"], str)
            assert isinstance(c["valid_to"], str)
            # Must be parseable as date
            date.fromisoformat(c["valid_from"])
            date.fromisoformat(c["valid_to"])

    def test_contract_valid_from_before_valid_to(self):
        for c in CONTRACTS:
            vf = date.fromisoformat(c["valid_from"])
            vt = date.fromisoformat(c["valid_to"])
            assert vf < vt

    def test_all_contracts_have_required_fields(self):
        required = ["id", "vendor_id", "vendor_name", "max_unit_rate", "max_total",
                    "valid_from", "valid_to", "description"]
        for c in CONTRACTS:
            for field in required:
                assert field in c, f"Missing field {field} in contract {c.get('id')}"


# ══════════════════════════════════════════════════════════════════════════════
# 4. Scenario generation tests
# ══════════════════════════════════════════════════════════════════════════════

class TestScenarios:
    def test_scenario_a_total_within_threshold(self):
        a = scenario_a()
        assert float(a.total_amount) == 4000.00
        assert float(a.total_amount) < 50000.00

    def test_scenario_a_all_unit_rates_within_threshold(self):
        a = scenario_a()
        for item in a.line_items:
            assert float(item.unit_rate) <= 4000.00

    def test_scenario_a_line_items_sum_matches_total(self):
        a = scenario_a()
        computed = sum(item.total for item in a.line_items)
        assert abs(computed - a.total_amount) < Decimal("0.01")

    def test_scenario_a_has_four_line_items(self):
        a = scenario_a()
        assert len(a.line_items) == 4

    def test_scenario_b_has_rate_violation(self):
        b = scenario_b()
        violations = [i for i in b.line_items if i.unit_rate > Decimal("4000.00")]
        assert len(violations) >= 1

    def test_scenario_b_violating_item_is_software_license(self):
        b = scenario_b()
        sw = next(i for i in b.line_items if "Software" in i.description)
        assert sw.unit_rate == Decimal("15000.00")

    def test_scenario_c_has_empty_line_items(self):
        c = scenario_c_raw()
        assert c["line_items"] == []

    def test_scenario_c_has_negative_total(self):
        c = scenario_c_raw()
        assert c["total_amount"] < 0

    def test_scenario_c_has_invalid_date(self):
        c = scenario_c_raw()
        assert c["invoice_date"] == "not-a-date"

    def test_scenario_c_has_null_vendor_name(self):
        c = scenario_c_raw()
        assert c["vendor"]["vendor_name"] is None

    def test_scenario_c_fails_pydantic_validation(self):
        c = scenario_c_raw()
        with pytest.raises(Exception):
            InvoicePayload(**c)


# ══════════════════════════════════════════════════════════════════════════════
# 5. Invoice parsing tests
# ══════════════════════════════════════════════════════════════════════════════

class TestInvoiceParsing:
    def test_parse_clean_json(self):
        raw = {
            "invoice_number": "INV-001",
            "vendor": {"vendor_id": "V-001", "vendor_name": "Test Corp"},
            "invoice_date": "2024-03-15",
            "currency": "USD",
            "line_items": [
                {"description": "Service", "quantity": 1, "unit_rate": 100.0,
                 "total": 100.0, "category": "services"}
            ],
            "total_amount": 100.0,
        }
        inv = _parse_raw_to_invoice(raw)
        assert inv.invoice_number == "INV-001"
        assert inv.vendor.vendor_name == "Test Corp"
        assert float(inv.total_amount) == 100.0
        assert len(inv.line_items) == 1

    def test_parse_with_currency_strings(self):
        raw = {
            "invoice_number": "INV-002",
            "vendor": {"vendor_id": "V-002", "vendor_name": "Acme"},
            "invoice_date": "2024-01-01",
            "currency": "USD",
            "line_items": [
                {"description": "Compute", "quantity": "720", "unit_rate": "$3.50",
                 "total": "$2,520.00", "category": "compute"}
            ],
            "total_amount": "$2,520.00",
        }
        inv = _parse_raw_to_invoice(raw)
        assert float(inv.total_amount) == 2520.00
        assert float(inv.line_items[0].unit_rate) == 3.50

    def test_parse_with_none_vendor_name(self):
        raw = {
            "invoice_number": "INV-003",
            "vendor": {"vendor_id": "", "vendor_name": None},
            "invoice_date": "2024-01-01",
            "currency": "USD",
            "line_items": [],
            "total_amount": 0,
        }
        # Should not crash — vendor_name None becomes "Unknown Vendor"
        # Empty line_items gets a placeholder item — policy check catches it later
        inv = _parse_raw_to_invoice(raw)
        assert inv.vendor.vendor_name == "Unknown Vendor"
        assert len(inv.line_items) == 1
        assert inv.line_items[0].description == "No line items extracted"

    def test_parse_missing_invoice_number(self):
        raw = {
            "vendor": {"vendor_id": "V-001", "vendor_name": "Test"},
            "invoice_date": "2024-01-01",
            "currency": "USD",
            "line_items": [],
            "total_amount": 0,
        }
        inv = _parse_raw_to_invoice(raw)
        assert inv.invoice_number == "UNKNOWN"
        # Empty line_items gets placeholder
        assert len(inv.line_items) == 1

    def test_parse_ocr_output_shape(self):
        """Exactly the shape Claude Vision returns."""
        ocr = {
            "invoice_number": "OCR-ACM-2024-03",
            "vendor": {
                "vendor_id": "AUTO-ACMECL",
                "vendor_name": "Acme Cloud Ltd",
                "contact_email": None,
                "address": "1 Tech Lane"
            },
            "invoice_date": "2024-03-01",
            "due_date": None,
            "currency": "USD",
            "line_items": [
                {"description": "Cloud Compute", "quantity": 720,
                 "unit_rate": 3.50, "total": 2520.00, "category": "compute"},
                {"description": "Storage 500GB", "quantity": 500,
                 "unit_rate": 2.00, "total": 1000.00, "category": "storage"},
            ],
            "total_amount": 3520.00,
            "notes": None
        }
        inv = _parse_raw_to_invoice(ocr)
        assert inv.invoice_number == "OCR-ACM-2024-03"
        assert len(inv.line_items) == 2
        assert float(inv.total_amount) == 3520.00

    def test_parse_negative_total(self):
        raw = {
            "invoice_number": "INV-NEG",
            "vendor": {"vendor_id": "V-001", "vendor_name": "Test"},
            "invoice_date": "2024-01-01",
            "currency": "USD",
            "line_items": [],
            "total_amount": -9999.99,
        }
        # Should not crash — negative total passes through, policy check flags it
        inv = _parse_raw_to_invoice(raw)
        assert float(inv.total_amount) == -9999.99
        assert len(inv.line_items) == 1  # placeholder added


# ══════════════════════════════════════════════════════════════════════════════
# 6. OCR benchmark scoring tests
# ══════════════════════════════════════════════════════════════════════════════

class TestOCRBenchmark:
    def test_perfect_match(self):
        extracted = {"invoice_number": "INV-001", "total_amount": "1234.56",
                     "invoice_date": "2024-03-15"}
        gt = {"gt_parse": {"invoice_number": "INV-001", "total_amount": "1234.56",
                           "invoice_date": "2024-03-15"}}
        score = _score_ocr_vs_ground_truth(extracted, gt)
        assert score["overall_accuracy_pct"] == 100.0

    def test_amount_with_currency_symbol(self):
        extracted = {"invoice_number": "X", "total_amount": "$1,234.56",
                     "invoice_date": "2024-01-01"}
        gt = {"invoice_number": "X", "total_amount": "1234.56",
              "invoice_date": "2024-01-01"}
        score = _score_ocr_vs_ground_truth(extracted, gt)
        assert score["total_amount"]["match"] is True

    def test_amount_tolerance(self):
        """Within $0.02 counts as match."""
        extracted = {"invoice_number": "X", "total_amount": "1234.57",
                     "invoice_date": "2024-01-01"}
        gt = {"invoice_number": "X", "total_amount": "1234.56",
              "invoice_date": "2024-01-01"}
        score = _score_ocr_vs_ground_truth(extracted, gt)
        assert score["total_amount"]["match"] is True

    def test_full_mismatch(self):
        extracted = {"invoice_number": "WRONG", "total_amount": "0",
                     "invoice_date": "2000-01-01"}
        gt = {"invoice_number": "INV-001", "total_amount": "1234.56",
              "invoice_date": "2024-03-15"}
        score = _score_ocr_vs_ground_truth(extracted, gt)
        assert score["overall_accuracy_pct"] == 0.0

    def test_partial_match(self):
        extracted = {"invoice_number": "INV-001", "total_amount": "999.00",
                     "invoice_date": "2024-01-01"}
        gt = {"invoice_number": "INV-001", "total_amount": "1234.56",
              "invoice_date": "2024-01-01"}
        score = _score_ocr_vs_ground_truth(extracted, gt)
        assert 0.0 < score["overall_accuracy_pct"] < 100.0

    def test_none_values_dont_crash(self):
        extracted = {"invoice_number": None, "total_amount": None,
                     "invoice_date": None}
        gt = {"invoice_number": "INV-001", "total_amount": "100.00",
              "invoice_date": "2024-01-01"}
        score = _score_ocr_vs_ground_truth(extracted, gt)
        assert "overall_accuracy_pct" in score


# ══════════════════════════════════════════════════════════════════════════════
# 7. Orchestrator routing tests
# ══════════════════════════════════════════════════════════════════════════════

class TestOrchestatorRouting:
    def test_transient_connection_error(self):
        assert _is_transient("connection error to API") is True

    def test_transient_timeout(self):
        assert _is_transient("timeout after 30s") is True

    def test_transient_refused(self):
        assert _is_transient("connection refused") is True

    def test_not_transient_404(self):
        assert _is_transient("Invoice INV-X not found") is False

    def test_not_transient_validation(self):
        assert _is_transient("Pydantic validation failed") is False

    def test_not_transient_none(self):
        assert _is_transient(None) is False

    def test_not_transient_empty(self):
        assert _is_transient("") is False

    def test_route_after_ingest_validating(self):
        gs = GraphState(
            invoice_number="TEST",
            orchestrator_state=OrchestratorState.VALIDATING
        )
        assert route_after_ingest(gs) == "validate"

    def test_route_after_ingest_error_non_transient(self):
        gs = GraphState(
            invoice_number="TEST",
            orchestrator_state=OrchestratorState.ERROR,
            extraction_error="Invoice not found"
        )
        assert route_after_ingest(gs) == "alert"

    def test_route_after_validate_compliant(self):
        gs = GraphState(
            invoice_number="TEST",
            orchestrator_state=OrchestratorState.COMPLIANT
        )
        assert route_after_validate(gs) == "settle"

    def test_route_after_validate_anomalous(self):
        gs = GraphState(
            invoice_number="TEST",
            orchestrator_state=OrchestratorState.ANOMALOUS
        )
        assert route_after_validate(gs) == "alert"

    def test_route_after_validate_error(self):
        gs = GraphState(
            invoice_number="TEST",
            orchestrator_state=OrchestratorState.ERROR
        )
        assert route_after_validate(gs) == "alert"

    def test_route_after_settle_complete(self):
        gs = GraphState(
            invoice_number="TEST",
            orchestrator_state=OrchestratorState.COMPLETE
        )
        assert route_after_settle(gs) == "__end__"

    def test_route_after_settle_error(self):
        gs = GraphState(
            invoice_number="TEST",
            orchestrator_state=OrchestratorState.ERROR
        )
        assert route_after_settle(gs) == "alert"


# ══════════════════════════════════════════════════════════════════════════════
# 8. HuggingFace routing tests
# ══════════════════════════════════════════════════════════════════════════════

class TestHFRouting:
    def test_hf_prefix_detected(self):
        assert "HF:voxel51:0".startswith("HF:")
        assert "HF:mychen76:5".startswith("HF:")
        assert "INV-SCENARIO-A".startswith("HF:") is False

    def test_hf_parts_parsed_correctly(self):
        parts = "HF:voxel51:42".split(":")
        assert parts[1] == "voxel51"
        assert int(parts[2]) == 42

    def test_hf_mychen76_parsed(self):
        parts = "HF:mychen76:499".split(":")
        assert parts[1] == "mychen76"
        assert int(parts[2]) == 499

    def test_hf_dataset_registry_complete(self):
        assert "voxel51" in HF_DATASETS
        assert "mychen76" in HF_DATASETS
        assert HF_DATASETS["voxel51"]["hf_id"] == "Voxel51/high-quality-invoice-images-for-ocr"
        assert HF_DATASETS["mychen76"]["hf_id"] == "mychen76/invoices-and-receipts_ocr_v1"
        assert HF_DATASETS["mychen76"]["type"] == "image_with_ground_truth"

    def test_sample_count_defaults(self):
        import os
        assert int(os.getenv("VOXEL51_SAMPLES", "500")) == 500
        assert int(os.getenv("MYCHEN76_SAMPLES", "500")) == 500

    def test_500_samples_produce_correct_invoice_numbers(self):
        scenarios = []
        for i in range(500):
            scenarios.append(f"HF:voxel51:{i}")
        for i in range(500):
            scenarios.append(f"HF:mychen76:{i}")
        assert len(scenarios) == 1000
        assert scenarios[0] == "HF:voxel51:0"
        assert scenarios[499] == "HF:voxel51:499"
        assert scenarios[500] == "HF:mychen76:0"
        assert scenarios[999] == "HF:mychen76:499"


# ══════════════════════════════════════════════════════════════════════════════
# 9. Policy check logic tests
# ══════════════════════════════════════════════════════════════════════════════

class TestPolicyCheck:
    def _check(self, invoice_dict: dict, contracts: list = None) -> dict:
        """Simulate API 3 policy check logic inline."""
        from decimal import Decimal as D
        flags = []
        violations = []
        score = 100.0
        contracts = contracts or []

        line_items   = invoice_dict.get("line_items", [])
        total_amount = D(str(invoice_dict.get("total_amount", 0)))

        max_unit  = D("4000.00")
        max_total = D("50000.00")

        if not line_items:
            flags.append({"field": "line_items", "reason": "No line items", "severity": "critical"})
            violations.append("EMPTY_LINE_ITEMS")
            score -= 50.0

        for item in line_items:
            rate = D(str(item.get("unit_rate", 0)))
            if rate > max_unit:
                flags.append({"field": item["description"], "reason": f"Rate ${rate} > ${max_unit}", "severity": "high"})
                violations.append(f"UNIT_RATE_EXCEEDED:{item['description']}")
                score -= 30.0

        if total_amount > max_total:
            violations.append("TOTAL_EXCEEDS_LIMIT")
            score -= 20.0

        if total_amount < 0:
            violations.append("NEGATIVE_TOTAL")
            score -= 50.0

        score = max(0.0, min(100.0, score))
        return {"passed": len(violations) == 0, "score": score, "violations": violations, "flags": flags}

    def test_scenario_a_passes(self):
        a = scenario_a()
        result = self._check(a.model_dump(mode="json"))
        assert result["passed"] is True
        assert result["score"] == 100.0

    def test_scenario_b_fails_unit_rate(self):
        b = scenario_b()
        result = self._check(b.model_dump(mode="json"))
        assert result["passed"] is False
        assert any("UNIT_RATE_EXCEEDED" in v for v in result["violations"])
        assert result["score"] < 100.0

    def test_scenario_c_fails_empty_items(self):
        result = self._check({"line_items": [], "total_amount": -9999.99})
        assert result["passed"] is False
        assert "EMPTY_LINE_ITEMS" in result["violations"]
        assert "NEGATIVE_TOTAL" in result["violations"]
        assert result["score"] == 0.0

    def test_negative_total_flagged(self):
        result = self._check({"line_items": [
            {"description": "X", "unit_rate": 100, "total": 100, "quantity": 1}
        ], "total_amount": -500})
        assert "NEGATIVE_TOTAL" in result["violations"]

    def test_total_exceeds_limit_flagged(self):
        result = self._check({"line_items": [
            {"description": "X", "unit_rate": 100, "total": 60000, "quantity": 1}
        ], "total_amount": 60000})
        assert "TOTAL_EXCEEDS_LIMIT" in result["violations"]


# ══════════════════════════════════════════════════════════════════════════════
# 10. CSV export tests
# ══════════════════════════════════════════════════════════════════════════════

class TestCSVExport:
    def test_csv_row_with_none_errors_no_crash(self):
        """The crash that killed Scenario B — must never happen again."""
        state = {
            "invoice_number": "INV-TEST",
            "extracted_invoice": None,
            "validation_result": None,
            "ledger_response": None,
            "notification_response": None,
            "orchestrator_state": "OrchestratorState.ERROR",
            "extraction_error": None,     # ← the killer
            "validation_error": None,
            "settlement_error": None,
        }
        # Simulate what export_csv does
        err_msg = state.get("extraction_error") or state.get("validation_error") or ""
        decision = f"ERROR: {str(err_msg)[:50]}"
        assert decision == "ERROR: "  # no crash

    def test_csv_row_with_string_error(self):
        state = {
            "extraction_error": "Pydantic validation failed: line items empty",
            "validation_error": None,
            "settlement_error": None,
        }
        err_msg = state.get("extraction_error") or state.get("validation_error") or ""
        decision = f"ERROR: {str(err_msg)[:50]}"
        assert "Pydantic" in decision

    def test_csv_row_approved(self):
        ledger_id = "abc-123"
        alert_id  = ""
        if ledger_id:
            decision = "APPROVED -> LEDGER"
        elif alert_id:
            decision = "FLAGGED -> ALERT SENT"
        else:
            decision = "ERROR"
        assert decision == "APPROVED -> LEDGER"

    def test_csv_row_flagged(self):
        ledger_id = ""
        alert_id  = "alert-abc123"
        if ledger_id:
            decision = "APPROVED -> LEDGER"
        elif alert_id:
            decision = "FLAGGED -> ALERT SENT"
        else:
            decision = "ERROR"
        assert decision == "FLAGGED -> ALERT SENT"


# ══════════════════════════════════════════════════════════════════════════════
# 11. Agent 1 mock tests (no real HTTP)
# ══════════════════════════════════════════════════════════════════════════════

class TestAgent1Mock:
    @pytest.mark.asyncio
    async def test_structured_path_success(self):
        """Agent 1 structured path with mocked MCP API."""
        from agents.agent1_ingestion import ingest_and_extract

        mock_payload = scenario_a().model_dump(mode="json")
        mock_response = MagicMock()
        mock_response.status_code = 200
        mock_response.json.return_value = {
            "invoice_number": "INV-SCENARIO-A",
            "payload": mock_payload
        }
        mock_response.raise_for_status = MagicMock()

        with patch("httpx.AsyncClient") as mock_client:
            mock_client.return_value.__aenter__ = AsyncMock(
                return_value=MagicMock(get=AsyncMock(return_value=mock_response))
            )
            mock_client.return_value.__aexit__ = AsyncMock(return_value=False)

            state = GraphState(
                invoice_number="INV-SCENARIO-A",
                orchestrator_state=OrchestratorState.INGESTING
            )
            result = await ingest_and_extract(state)

        assert result.orchestrator_state == OrchestratorState.VALIDATING
        assert result.extraction_error == ""

    @pytest.mark.asyncio
    async def test_structured_path_404(self):
        """Agent 1 handles 404 gracefully."""
        from agents.agent1_ingestion import ingest_and_extract
        import httpx as _httpx

        mock_response = MagicMock()
        mock_response.status_code = 404
        mock_response.text = "Not found"

        http_error = _httpx.HTTPStatusError(
            "404", request=MagicMock(), response=mock_response
        )

        with patch("httpx.AsyncClient") as mock_client:
            mock_get = AsyncMock(side_effect=http_error)
            mock_client.return_value.__aenter__ = AsyncMock(
                return_value=MagicMock(get=mock_get)
            )
            mock_client.return_value.__aexit__ = AsyncMock(return_value=False)

            state = GraphState(
                invoice_number="INV-NONEXISTENT",
                orchestrator_state=OrchestratorState.INGESTING
            )
            result = await ingest_and_extract(state)

        assert result.orchestrator_state == OrchestratorState.ERROR
        assert "not found" in result.extraction_error.lower()
        assert result.extraction_error[:50] is not None  # no crash


# ══════════════════════════════════════════════════════════════════════════════
# 12. End-to-end state machine tests (no real HTTP)
# ══════════════════════════════════════════════════════════════════════════════

class TestStateMachine:
    def test_scenario_a_state_flow(self):
        """Scenario A: INGESTING → VALIDATING → COMPLIANT → SETTLING → COMPLETE"""
        states = [OrchestratorState.INGESTING]
        gs = GraphState(invoice_number="INV-A", orchestrator_state=OrchestratorState.INGESTING)

        # After ingest
        gs.orchestrator_state = OrchestratorState.VALIDATING
        assert route_after_ingest(gs) == "validate"

        # After validate
        gs.orchestrator_state = OrchestratorState.COMPLIANT
        assert route_after_validate(gs) == "settle"

        # After settle
        gs.orchestrator_state = OrchestratorState.COMPLETE
        assert route_after_settle(gs) == "__end__"

    def test_scenario_b_state_flow(self):
        """Scenario B: INGESTING → VALIDATING → ANOMALOUS → ALERTING → COMPLETE"""
        gs = GraphState(invoice_number="INV-B", orchestrator_state=OrchestratorState.INGESTING)

        gs.orchestrator_state = OrchestratorState.VALIDATING
        assert route_after_ingest(gs) == "validate"

        gs.orchestrator_state = OrchestratorState.ANOMALOUS
        assert route_after_validate(gs) == "alert"

    def test_scenario_c_state_flow(self):
        """Scenario C: INGESTING → ERROR → ALERTING → COMPLETE"""
        gs = GraphState(
            invoice_number="INV-C",
            orchestrator_state=OrchestratorState.ERROR,
            extraction_error="Pydantic validation failed"
        )
        assert route_after_ingest(gs) == "alert"
        assert _is_transient(gs.extraction_error) is False

    def test_error_state_with_transient_no_retry_after_max(self):
        """After max retries, transient error goes to alert not retry."""
        gs = GraphState(
            invoice_number="INV-RETRY",
            orchestrator_state=OrchestratorState.ERROR,
            extraction_error="connection error",
            retry_count=3,
            max_retries=3
        )
        assert route_after_ingest(gs) == "alert"
