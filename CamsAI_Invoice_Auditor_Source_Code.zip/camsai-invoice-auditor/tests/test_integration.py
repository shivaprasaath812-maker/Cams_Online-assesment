"""
Integration tests for CamsAI Invoice Auditor.
Requires docker-compose stack to be running.
Run: pytest tests/test_integration.py -v
"""
from __future__ import annotations

import asyncio
import json
import os
import pytest
import httpx

MCP_URL = os.getenv("MCP_URL", "http://localhost:8080")


# ──────────────────────────────────────────────────────────────────────────────
# Fixtures
# ──────────────────────────────────────────────────────────────────────────────

@pytest.fixture(scope="session")
def event_loop():
    loop = asyncio.new_event_loop()
    yield loop
    loop.close()


@pytest.fixture(scope="session")
async def mcp_client():
    async with httpx.AsyncClient(base_url=MCP_URL, timeout=30) as client:
        yield client


# ──────────────────────────────────────────────────────────────────────────────
# MCP Health
# ──────────────────────────────────────────────────────────────────────────────

@pytest.mark.asyncio
async def test_mcp_health(mcp_client):
    r = await mcp_client.get("/health")
    assert r.status_code == 200
    data = r.json()
    assert data["status"] == "ok"
    print(f"\n✓ MCP health OK — payloads loaded: {data['payloads_loaded']}")


# ──────────────────────────────────────────────────────────────────────────────
# API 1: Payload Fetch
# ──────────────────────────────────────────────────────────────────────────────

@pytest.mark.asyncio
async def test_api1_fetch_scenario_a(mcp_client):
    r = await mcp_client.get("/api/v1/payloads/INV-SCENARIO-A")
    assert r.status_code == 200
    data = r.json()
    assert data["payload"]["scenario"] == "A"
    assert float(data["payload"]["total_amount"]) == 4000.00
    print(f"\n✓ API1 Scenario A fetched — total: ${data['payload']['total_amount']}")


@pytest.mark.asyncio
async def test_api1_fetch_scenario_b(mcp_client):
    r = await mcp_client.get("/api/v1/payloads/INV-SCENARIO-B")
    assert r.status_code == 200
    data = r.json()
    assert data["payload"]["scenario"] == "B"
    print(f"\n✓ API1 Scenario B fetched — vendor: {data['payload']['vendor']['vendor_name']}")


@pytest.mark.asyncio
async def test_api1_fetch_scenario_c(mcp_client):
    r = await mcp_client.get("/api/v1/payloads/INV-SCENARIO-C")
    assert r.status_code == 200
    data = r.json()
    assert data["payload"]["scenario"] == "C"
    print(f"\n✓ API1 Scenario C fetched (malformed) — total: {data['payload']['total_amount']}")


@pytest.mark.asyncio
async def test_api1_not_found(mcp_client):
    r = await mcp_client.get("/api/v1/payloads/INV-NONEXISTENT")
    assert r.status_code == 404
    print("\n✓ API1 404 on nonexistent invoice")


# ──────────────────────────────────────────────────────────────────────────────
# API 2: Vector Query
# ──────────────────────────────────────────────────────────────────────────────

@pytest.mark.asyncio
async def test_api2_vector_query(mcp_client):
    r = await mcp_client.post("/api/v1/vector/query", json={
        "vendor_id": "VENDOR-001",
        "vendor_name": "Acme Cloud Services",
        "service_categories": ["compute", "storage"],
        "n_results": 2
    })
    assert r.status_code == 200
    data = r.json()
    assert "contracts" in data
    print(f"\n✓ API2 Vector query returned {len(data['contracts'])} contract(s)")
    if data["contracts"]:
        c = data["contracts"][0]
        print(f"  Best match: {c.get('vendor_name')} (similarity={c.get('similarity')})")


# ──────────────────────────────────────────────────────────────────────────────
# API 3: Policy Check
# ──────────────────────────────────────────────────────────────────────────────

@pytest.mark.asyncio
async def test_api3_policy_compliant(mcp_client):
    """Scenario A invoice should pass policy check."""
    r = await mcp_client.get("/api/v1/payloads/INV-SCENARIO-A")
    invoice = r.json()["payload"]

    r2 = await mcp_client.post("/api/v1/policy/check", json={"invoice": invoice, "contracts": []})
    assert r2.status_code == 200
    data = r2.json()
    assert data["passed"] is True
    assert data["compliance_score"] == 100.0
    print(f"\n✓ API3 Scenario A policy check PASSED — score: {data['compliance_score']}")


@pytest.mark.asyncio
async def test_api3_policy_anomalous(mcp_client):
    """Scenario B invoice should fail with unit rate flags."""
    r = await mcp_client.get("/api/v1/payloads/INV-SCENARIO-B")
    invoice = r.json()["payload"]

    r2 = await mcp_client.post("/api/v1/policy/check", json={"invoice": invoice, "contracts": []})
    assert r2.status_code == 200
    data = r2.json()
    assert data["passed"] is False
    assert len(data["anomaly_flags"]) > 0
    print(f"\n✓ API3 Scenario B policy check FAILED (expected) — "
          f"flags: {len(data['anomaly_flags'])} score: {data['compliance_score']}")
    for flag in data["anomaly_flags"]:
        print(f"  • {flag['field']}: {flag['reason']}")


# ──────────────────────────────────────────────────────────────────────────────
# API 4 + 5: End-to-end via Orchestrator (lightweight)
# ──────────────────────────────────────────────────────────────────────────────

@pytest.mark.asyncio
async def test_full_scenario_a_pipeline(mcp_client):
    """
    Simulate the Scenario A pipeline manually through APIs 1-4.
    (Full graph test runs via docker orchestrator service)
    """
    # API 1
    r1 = await mcp_client.get("/api/v1/payloads/INV-SCENARIO-A")
    invoice = r1.json()["payload"]

    # API 2
    r2 = await mcp_client.post("/api/v1/vector/query", json={
        "vendor_id": invoice["vendor"]["vendor_id"],
        "vendor_name": invoice["vendor"]["vendor_name"],
        "service_categories": [i.get("category", "general") for i in invoice["line_items"]]
    })
    contracts = r2.json().get("contracts", [])

    # API 3
    r3 = await mcp_client.post("/api/v1/policy/check", json={
        "invoice": invoice, "contracts": contracts
    })
    validation = r3.json()
    assert validation["passed"] is True

    # API 4 (Ledger write)
    from mock_data.schemas import InvoicePayload, ValidationResult, LedgerWriteRequest, OrchestratorState
    inv_obj = InvoicePayload(**invoice)
    val_obj = ValidationResult(**validation)
    req = LedgerWriteRequest(invoice=inv_obj, validation=val_obj,
                              orchestrator_state=OrchestratorState.SETTLING)
    r4 = await mcp_client.post("/api/v1/ledger/write", json=req.model_dump(mode="json"))
    assert r4.status_code == 200
    ledger = r4.json()
    assert ledger["success"] is True
    print(f"\n✓ Scenario A full pipeline → Ledger ID: {ledger['invoice_id']}")


@pytest.mark.asyncio
async def test_notification_api(mcp_client):
    """Test API 5 notification endpoint."""
    from mock_data.schemas import OrchestratorState
    r = await mcp_client.post("/api/v1/notify/alert", json={
        "invoice_number": "INV-TEST-NOTIFY",
        "vendor_name": "Test Vendor",
        "total_amount": "15000.00",
        "anomaly_flags": [
            {"field": "unit_rate", "reason": "Exceeds threshold", "severity": "high", "value": 15000}
        ],
        "severity": "high",
        "recipient_email": "test@example.com",
        "orchestrator_state": OrchestratorState.ANOMALOUS.value
    })
    assert r.status_code == 200
    data = r.json()
    assert data["sent"] is True
    print(f"\n✓ API5 Notification sent via {data['channel']}: msg_id={data['message_id']}")
