"""
CamsAI Invoice Auditor — Data Seeder
Errorproof: retries, proper UUIDs, ChromaDB version-safe operations.
"""
from __future__ import annotations

import asyncio
import json
import logging
import os
import sys
import time
import uuid
from datetime import date, timedelta
from decimal import Decimal
from pathlib import Path

import asyncpg
import chromadb
import httpx

sys.path.insert(0, str(Path(__file__).parent.parent))
from mock_data.schemas import InvoicePayload, LineItem, VendorInfo

logging.basicConfig(level=logging.INFO, format="%(asctime)s [SEEDER] %(message)s")
log = logging.getLogger(__name__)

MCP_URL      = os.getenv("MCP_URL", "http://localhost:8080")
CHROMA_HOST  = os.getenv("CHROMA_HOST", "localhost")
CHROMA_PORT  = int(os.getenv("CHROMA_PORT", "8000"))
DATABASE_URL = os.getenv(
    "DATABASE_URL",
    "postgresql://auditor:auditor_secret@localhost:5432/invoice_ledger"
)


# ── Scenarios ─────────────────────────────────────────────────────────────────

def scenario_a() -> InvoicePayload:
    return InvoicePayload(
        invoice_number="INV-SCENARIO-A",
        vendor=VendorInfo(
            vendor_id="VENDOR-001",
            vendor_name="Acme Cloud Services",
            contact_email="billing@acme-cloud.example.com"
        ),
        invoice_date=date.today() - timedelta(days=3),
        due_date=date.today() + timedelta(days=27),
        currency="USD",
        line_items=[
            LineItem(description="Cloud Compute t3.large x 720 hrs",
                     quantity=Decimal("720"), unit_rate=Decimal("3.50"),
                     total=Decimal("2520.00"), category="compute"),
            LineItem(description="Managed Database Storage 500 GB",
                     quantity=Decimal("500"), unit_rate=Decimal("2.00"),
                     total=Decimal("1000.00"), category="storage"),
            LineItem(description="Data Transfer Egress 1 TB",
                     quantity=Decimal("1"), unit_rate=Decimal("80.00"),
                     total=Decimal("80.00"), category="network"),
            LineItem(description="24x7 Premium Support",
                     quantity=Decimal("1"), unit_rate=Decimal("400.00"),
                     total=Decimal("400.00"), category="support"),
        ],
        total_amount=Decimal("4000.00"),
        notes="Monthly cloud services Q3 cycle",
        scenario="A"
    )


def scenario_b() -> InvoicePayload:
    return InvoicePayload(
        invoice_number="INV-SCENARIO-B",
        vendor=VendorInfo(
            vendor_id="VENDOR-002",
            vendor_name="ShadyByte Consulting",
            contact_email="invoices@shadybyte.example.com"
        ),
        invoice_date=date.today() - timedelta(days=1),
        due_date=date.today() + timedelta(days=14),
        currency="USD",
        line_items=[
            LineItem(description="Software License Enterprise Tier",
                     quantity=Decimal("1"), unit_rate=Decimal("15000.00"),
                     total=Decimal("15000.00"), category="software"),
            LineItem(description="Integration Consulting 20 hrs",
                     quantity=Decimal("20"), unit_rate=Decimal("250.00"),
                     total=Decimal("5000.00"), category="consulting"),
            LineItem(description="Data Migration Package",
                     quantity=Decimal("1"), unit_rate=Decimal("3800.00"),
                     total=Decimal("3800.00"), category="services"),
        ],
        total_amount=Decimal("23800.00"),
        notes="Enterprise onboarding package",
        scenario="B"
    )


def scenario_c_raw() -> dict:
    return {
        "invoice_number": "INV-SCENARIO-C",
        "vendor": {"vendor_id": "", "vendor_name": None},
        "invoice_date": "not-a-date",
        "currency": "USD",
        "line_items": [],
        "total_amount": -9999.99,
        "scenario": "C"
    }


# ── Contracts — valid UUIDs ────────────────────────────────────────────────────

CONTRACTS = [
    {
        "id": "a0000000-0000-0000-0000-000000000001",
        "vendor_id": "VENDOR-001",
        "vendor_name": "Acme Cloud Services",
        "service_category": "compute",
        "max_unit_rate": 4000.00,
        "max_total": 50000.00,
        "valid_from": str(date.today() - timedelta(days=365)),
        "valid_to":   str(date.today() + timedelta(days=365)),
        "description": (
            "Acme Cloud Services: approved for compute, storage, network, support. "
            "Max unit rate $4,000. Max invoice total $50,000 per billing cycle."
        )
    },
    {
        "id": "a0000000-0000-0000-0000-000000000002",
        "vendor_id": "VENDOR-002",
        "vendor_name": "ShadyByte Consulting",
        "service_category": "consulting",
        "max_unit_rate": 4000.00,
        "max_total": 50000.00,
        "valid_from": str(date.today() - timedelta(days=180)),
        "valid_to":   str(date.today() + timedelta(days=180)),
        "description": (
            "ShadyByte Consulting: approved for software, consulting, services. "
            "Max unit rate $4,000. Items exceeding $4,000 unit rate require CFO approval."
        )
    },
    {
        "id": "a0000000-0000-0000-0000-000000000003",
        "vendor_id": "VENDOR-003",
        "vendor_name": "GlobalLogic Partners",
        "service_category": "professional_services",
        "max_unit_rate": 3500.00,
        "max_total": 75000.00,
        "valid_from": str(date.today() - timedelta(days=90)),
        "valid_to":   str(date.today() + timedelta(days=275)),
        "description": (
            "GlobalLogic Partners: professional services, architecture, DevOps. "
            "Max unit rate $3,500. Max total $75,000."
        )
    },
]


# ── PostgreSQL seed ────────────────────────────────────────────────────────────

async def seed_postgres_contracts():
    log.info("Seeding PostgreSQL contracts...")
    dsn = DATABASE_URL.replace("postgresql+asyncpg://", "postgresql://")

    for attempt in range(1, 6):
        try:
            conn = await asyncpg.connect(dsn)
            try:
                for c in CONTRACTS:
                    vf = date.fromisoformat(c["valid_from"])
                    vt = date.fromisoformat(c["valid_to"])
                    await conn.execute("""
                        INSERT INTO contracts
                            (id, vendor_id, vendor_name, service_category,
                             max_unit_rate, max_total, valid_from, valid_to)
                        VALUES ($1,$2,$3,$4,$5,$6,$7,$8)
                        ON CONFLICT DO NOTHING
                    """, c["id"], c["vendor_id"], c["vendor_name"],
                        c["service_category"], c["max_unit_rate"],
                        c["max_total"], vf, vt)
                log.info(f"  ✓ Inserted {len(CONTRACTS)} contracts into PostgreSQL")
                return
            finally:
                await conn.close()
        except Exception as e:
            if attempt == 5:
                raise RuntimeError(f"PostgreSQL seed failed after 5 attempts: {e}")
            wait = attempt * 3
            log.warning(f"  ⚠ PostgreSQL attempt {attempt} failed: {e} — retry in {wait}s")
            await asyncio.sleep(wait)


# ── ChromaDB seed — version-safe ───────────────────────────────────────────────

def seed_chromadb_vectors():
    log.info("Seeding ChromaDB vector knowledge base...")

    for attempt in range(1, 6):
        try:
            client = chromadb.HttpClient(host=CHROMA_HOST, port=CHROMA_PORT)

            # Version-safe: try reset endpoint first, fall back to get_or_create
            try:
                # Try to reset the specific collection via HTTP directly
                import urllib.request
                req = urllib.request.Request(
                    f"http://{CHROMA_HOST}:{CHROMA_PORT}/api/v1/collections",
                    method="GET"
                )
                with urllib.request.urlopen(req, timeout=5) as r:
                    collections = json.loads(r.read())
                    names = [c.get("name", "") for c in collections]
                    if "vendor_contracts" in names:
                        client.delete_collection("vendor_contracts")
                        log.info("  ✓ Deleted old vendor_contracts collection")
                        time.sleep(2)
            except Exception as e:
                log.warning(f"  ⚠ Could not delete old collection: {e} — will get_or_create")

            # Create fresh collection
            try:
                collection = client.create_collection(
                    name="vendor_contracts",
                    metadata={"hnsw:space": "cosine"}
                )
            except Exception:
                # Already exists — get it and clear it
                collection = client.get_collection("vendor_contracts")
                try:
                    all_ids = collection.get()["ids"]
                    if all_ids:
                        collection.delete(ids=all_ids)
                except Exception:
                    pass

            # Add documents
            documents = [c["description"] for c in CONTRACTS]
            metadatas = [{
                "vendor_id":     c["vendor_id"],
                "vendor_name":   c["vendor_name"],
                "max_unit_rate": c["max_unit_rate"],
                "max_total":     c["max_total"],
                "valid_from":    c["valid_from"],
                "valid_to":      c["valid_to"],
            } for c in CONTRACTS]
            ids = [c["id"] for c in CONTRACTS]

            collection.add(documents=documents, metadatas=metadatas, ids=ids)

            count = collection.count()
            if count == 0:
                raise RuntimeError("Collection created but empty")

            log.info(f"  ✓ Embedded {count} vendor contracts into ChromaDB")
            return

        except Exception as e:
            if attempt == 5:
                raise RuntimeError(f"ChromaDB seed failed after 5 attempts: {e}")
            wait = attempt * 3
            log.warning(f"  ⚠ ChromaDB attempt {attempt} failed: {e} — retry in {wait}s")
            time.sleep(wait)


# ── MCP payload seed ──────────────────────────────────────────────────────────

async def seed_mcp_payload_store():
    log.info("Seeding MCP API-1 payload store...")

    scenarios = [
        (scenario_a().model_dump(mode="json"), "A"),
        (scenario_b().model_dump(mode="json"), "B"),
        (scenario_c_raw(), "C"),
    ]

    for payload, label in scenarios:
        for attempt in range(1, 6):
            try:
                async with httpx.AsyncClient(timeout=30) as client:
                    r = await client.post(
                        f"{MCP_URL}/api/v1/payloads/seed",
                        json={"payload": payload, "scenario": label}
                    )
                    r.raise_for_status()
                log.info(f"  ✓ Scenario {label} seeded: {payload.get('invoice_number')}")
                break
            except Exception as e:
                if attempt == 5:
                    raise RuntimeError(f"MCP seed scenario {label} failed: {e}")
                wait = attempt * 3
                log.warning(f"  ⚠ MCP scenario {label} attempt {attempt} failed: {e} — retry in {wait}s")
                await asyncio.sleep(wait)


# ── Main ──────────────────────────────────────────────────────────────────────

async def main():
    log.info("=" * 60)
    log.info("  CamsAI Invoice Auditor — Data Seeder")
    log.info("=" * 60)

    await seed_postgres_contracts()
    seed_chromadb_vectors()
    await seed_mcp_payload_store()

    log.info("=" * 60)
    log.info("  All seeds complete. System ready.")
    log.info("=" * 60)


if __name__ == "__main__":
    asyncio.run(main())
