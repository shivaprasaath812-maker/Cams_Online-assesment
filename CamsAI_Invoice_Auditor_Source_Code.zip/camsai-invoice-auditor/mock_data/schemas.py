"""
Shared Pydantic models for the CamsAI Invoice Auditing system.
Used by MCP Server, Agents, and Seeder.
"""
from __future__ import annotations

import uuid
from datetime import date, datetime
from decimal import Decimal
from enum import Enum
from typing import Any

from pydantic import BaseModel, Field, field_validator


# ──────────────────────────────────────────────────────────────────────────────
# Enums
# ──────────────────────────────────────────────────────────────────────────────

class InvoiceStatus(str, Enum):
    PENDING   = "pending"
    APPROVED  = "approved"
    FLAGGED   = "flagged"
    REJECTED  = "rejected"
    ERROR     = "error"


class OrchestratorState(str, Enum):
    INGESTING   = "INGESTING"
    VALIDATING  = "VALIDATING"
    COMPLIANT   = "COMPLIANT"
    ANOMALOUS   = "ANOMALOUS"
    SETTLING    = "SETTLING"
    ALERTING    = "ALERTING"
    COMPLETE    = "COMPLETE"
    ERROR       = "ERROR"


# ──────────────────────────────────────────────────────────────────────────────
# Invoice primitives
# ──────────────────────────────────────────────────────────────────────────────

class LineItem(BaseModel):
    description: str
    quantity: Decimal
    unit_rate: Decimal
    total: Decimal
    category: str = "general"

    @field_validator("quantity", "unit_rate", "total", mode="before")
    @classmethod
    def must_be_positive(cls, v: Any) -> Decimal:
        d = Decimal(str(v))
        if d < 0:
            raise ValueError(f"Line item values must be non-negative, got {d}")
        return d


class VendorInfo(BaseModel):
    vendor_id: str
    vendor_name: str
    contact_email: str | None = None
    address: str | None = None


class InvoicePayload(BaseModel):
    invoice_number: str = Field(default_factory=lambda: f"INV-{uuid.uuid4().hex[:8].upper()}")
    vendor: VendorInfo
    invoice_date: date
    due_date: date | None = None
    currency: str = "USD"
    line_items: list[LineItem]
    total_amount: Decimal
    notes: str | None = None
    scenario: str | None = None   # A | B | C (for test routing)

    @field_validator("line_items")
    @classmethod
    def items_not_empty(cls, v: list[LineItem]) -> list[LineItem]:
        if not v:
            raise ValueError("Invoice must have at least one line item")
        return v


# ──────────────────────────────────────────────────────────────────────────────
# Validation results
# ──────────────────────────────────────────────────────────────────────────────

class AnomalyFlag(BaseModel):
    field: str
    reason: str
    severity: str = "medium"   # low | medium | high | critical
    value: Any | None = None


class ValidationResult(BaseModel):
    passed: bool
    compliance_score: float = Field(ge=0.0, le=100.0)
    anomaly_flags: list[AnomalyFlag] = []
    policy_violations: list[str] = []
    vector_match_score: float | None = None
    recommendation: str = ""


# ──────────────────────────────────────────────────────────────────────────────
# Ledger / settlement
# ──────────────────────────────────────────────────────────────────────────────

class LedgerEntry(BaseModel):
    invoice_id: str
    invoice_number: str
    vendor_id: str
    total_amount: Decimal
    status: InvoiceStatus
    compliance_score: float | None
    anomaly_flags: list[AnomalyFlag] = []
    settled_at: datetime | None = None


class LedgerWriteRequest(BaseModel):
    invoice: InvoicePayload
    validation: ValidationResult
    orchestrator_state: OrchestratorState


class LedgerWriteResponse(BaseModel):
    success: bool
    invoice_id: str
    message: str


# ──────────────────────────────────────────────────────────────────────────────
# Notifications
# ──────────────────────────────────────────────────────────────────────────────

class NotificationRequest(BaseModel):
    invoice_number: str
    vendor_name: str
    total_amount: Decimal
    anomaly_flags: list[AnomalyFlag]
    severity: str
    recipient_email: str
    orchestrator_state: OrchestratorState


class NotificationResponse(BaseModel):
    sent: bool
    channel: str
    message_id: str | None = None
    error: str | None = None


# ──────────────────────────────────────────────────────────────────────────────
# Orchestrator graph state (LangGraph TypedDict-compatible via Pydantic)
# ──────────────────────────────────────────────────────────────────────────────

class GraphState(BaseModel):
    """Mutable state threaded through LangGraph nodes.
    Error fields are always str (never None) — coerced by validator.
    This prevents TypeError when slicing or formatting error messages.
    """
    # Input
    invoice_number: str | None = None
    raw_payload: dict | None = None

    # Agent 1 output
    extracted_invoice: InvoicePayload | None = None
    extraction_error: str = ""

    # Agent 2 output
    validation_result: ValidationResult | None = None
    validation_error: str = ""

    # Agent 3 output
    ledger_response: LedgerWriteResponse | None = None
    notification_response: NotificationResponse | None = None
    settlement_error: str = ""

    # Routing
    orchestrator_state: OrchestratorState = OrchestratorState.INGESTING
    retry_count: int = 0
    max_retries: int = 3

    model_config = {"use_enum_values": False}

    @field_validator("extraction_error", "validation_error", "settlement_error", mode="before")
    @classmethod
    def coerce_none_to_str(cls, v: Any) -> str:
        """None -> empty string. Prevents TypeError on slicing/formatting."""
        return "" if v is None else str(v)
