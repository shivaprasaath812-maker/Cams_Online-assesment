"""
Google Sheets Audit Logger for CamsAI Invoice Auditor
======================================================
Logs every orchestrator run result to a Google Sheet in real-time.

Each row contains:
  Timestamp | Invoice # | Scenario | Vendor | Total Amount | 
  Final State | Compliance Score | Flags | Decision | Ledger ID | Alert ID | Error

Setup:
  1. Share your Google Sheet with the service account email
  2. Set GOOGLE_SHEET_ID in .env
  3. Place service-account.json in the project root

OR use the simpler OAuth approach with just GOOGLE_SHEET_ID set.
"""
import asyncio
import json
import logging
import os
from datetime import datetime
from pathlib import Path

import httpx

log = logging.getLogger("SheetsLogger")

SHEET_ID    = os.getenv("GOOGLE_SHEET_ID", "")
SHEET_NAME  = os.getenv("GOOGLE_SHEET_NAME", "Invoice Audit Log")
MCP_URL     = os.getenv("MCP_URL", "http://localhost:8080")


# ── Header row ────────────────────────────────────────────────────────────────
HEADERS = [
    "Timestamp (IST)",
    "Invoice Number",
    "Scenario",
    "Vendor Name",
    "Total Amount (USD)",
    "Final State",
    "Decision",
    "Compliance Score",
    "Anomaly Flags",
    "Policy Violations",
    "Ledger ID",
    "Alert ID",
    "Extraction Error",
    "Validation Error",
    "Processing Time (s)"
]


def build_row(result: dict, processing_time: float = 0.0) -> list:
    """Convert a GraphState result dict into a flat row for Sheets."""
    now = datetime.now().strftime("%Y-%m-%d %H:%M:%S")

    invoice = result.get("extracted_invoice") or {}
    if isinstance(invoice, dict):
        vendor_name   = invoice.get("vendor", {}).get("vendor_name", "Unknown")
        total_amount  = invoice.get("total_amount", 0)
        invoice_num   = invoice.get("invoice_number", result.get("invoice_number", "?"))
        scenario      = invoice.get("scenario", "?")
    else:
        vendor_name   = "Unknown"
        total_amount  = 0
        invoice_num   = result.get("invoice_number", "?")
        scenario      = "?"

    val    = result.get("validation_result") or {}
    if isinstance(val, dict):
        compliance    = val.get("compliance_score", "N/A")
        flags         = len(val.get("anomaly_flags", []))
        violations    = ", ".join(val.get("policy_violations", [])) or "None"
    else:
        compliance    = "N/A"
        flags         = 0
        violations    = "None"

    ledger  = result.get("ledger_response") or {}
    ledger_id = ledger.get("invoice_id", "") if isinstance(ledger, dict) else ""

    notif   = result.get("notification_response") or {}
    alert_id = notif.get("message_id", "") if isinstance(notif, dict) else ""

    state   = str(result.get("orchestrator_state", "?"))
    state_clean = state.replace("OrchestratorState.", "")

    # Decision label
    if "COMPLETE" in state_clean and ledger_id:
        decision = "✅ APPROVED → LEDGER"
    elif "COMPLETE" in state_clean and alert_id:
        decision = "⚠️ FLAGGED → ALERT SENT"
    elif "ERROR" in state_clean:
        decision = "❌ ERROR → ALERT SENT"
    else:
        decision = state_clean

    return [
        now,
        invoice_num,
        scenario or "?",
        vendor_name,
        str(total_amount),
        state_clean,
        decision,
        str(compliance),
        str(flags),
        violations,
        ledger_id,
        alert_id,
        result.get("extraction_error", "") or "",
        result.get("validation_error", "") or "",
        f"{processing_time:.1f}s"
    ]


async def append_to_sheet(rows: list[list], access_token: str):
    """Append rows to Google Sheet via Sheets API v4."""
    if not SHEET_ID:
        log.warning("GOOGLE_SHEET_ID not set — skipping Sheets export")
        return False

    url = (
        f"https://sheets.googleapis.com/v4/spreadsheets/{SHEET_ID}"
        f"/values/{SHEET_NAME}!A1:append"
        f"?valueInputOption=USER_ENTERED&insertDataOption=INSERT_ROWS"
    )

    body = {"values": rows}
    headers = {
        "Authorization": f"Bearer {access_token}",
        "Content-Type": "application/json"
    }

    async with httpx.AsyncClient(timeout=15) as client:
        r = await client.post(url, json=body, headers=headers)
        if r.status_code == 200:
            log.info(f"[Sheets] ✓ Logged {len(rows)} row(s) to Google Sheet")
            return True
        else:
            log.error(f"[Sheets] Failed {r.status_code}: {r.text[:200]}")
            return False


async def ensure_header(access_token: str):
    """Write header row if sheet is empty."""
    if not SHEET_ID:
        return

    url = (
        f"https://sheets.googleapis.com/v4/spreadsheets/{SHEET_ID}"
        f"/values/{SHEET_NAME}!A1:O1"
    )
    headers = {"Authorization": f"Bearer {access_token}"}

    async with httpx.AsyncClient(timeout=10) as client:
        r = await client.get(url, headers=headers)
        data = r.json()
        existing = data.get("values", [])
        if not existing:
            # Sheet is empty — write headers
            write_url = (
                f"https://sheets.googleapis.com/v4/spreadsheets/{SHEET_ID}"
                f"/values/{SHEET_NAME}!A1?valueInputOption=USER_ENTERED"
            )
            await client.put(write_url, json={"values": [HEADERS]}, headers={
                **headers, "Content-Type": "application/json"
            })
            log.info("[Sheets] ✓ Header row written")


async def get_oauth_token_from_env() -> str:
    """
    Get OAuth token. In production use a service account.
    For quick setup, set GOOGLE_OAUTH_TOKEN directly in .env
    (generate via: https://developers.google.com/oauthplayground)
    """
    token = os.getenv("GOOGLE_OAUTH_TOKEN", "")
    if not token:
        raise ValueError(
            "GOOGLE_OAUTH_TOKEN not set. "
            "Generate one at https://developers.google.com/oauthplayground "
            "with scope: https://www.googleapis.com/auth/spreadsheets"
        )
    return token


async def log_run_to_sheets(result: dict, processing_time: float = 0.0):
    """
    Main entry point — call this after each orchestrator run.
    Appends one row to the Google Sheet.
    """
    try:
        token = await get_oauth_token_from_env()
        await ensure_header(token)
        row = build_row(result, processing_time)
        await append_to_sheet([row], token)
    except Exception as e:
        log.warning(f"[Sheets] Could not log to Google Sheets: {e}")


# ── Standalone: export all invoices from PostgreSQL to sheet ──────────────────
async def export_all_from_db():
    """
    Pull all invoices from PostgreSQL and write to Google Sheet.
    Run standalone: python scripts/sheets_logger.py
    """
    import asyncpg
    DATABASE_URL = os.getenv(
        "DATABASE_URL",
        "postgresql://auditor:auditor_secret@localhost:5432/invoice_ledger"
    ).replace("postgresql+asyncpg://", "postgresql://")

    log.info("Connecting to PostgreSQL...")
    conn = await asyncpg.connect(DATABASE_URL)
    rows = await conn.fetch("""
        SELECT
            i.invoice_number,
            i.vendor_name,
            i.total_amount,
            i.status,
            i.compliance_score,
            i.anomaly_flags,
            i.created_at,
            (SELECT ae.payload FROM audit_events ae
             WHERE ae.invoice_id = i.id
             ORDER BY ae.created_at DESC LIMIT 1) as last_event
        FROM invoices i
        ORDER BY i.created_at DESC
    """)
    await conn.close()

    now = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    sheet_rows = [HEADERS]  # Write headers first

    for r in rows:
        flags = json.loads(r["anomaly_flags"] or "[]")
        status = r["status"].upper()
        if status == "APPROVED":
            decision = "✅ APPROVED → LEDGER"
        elif status == "FLAGGED":
            decision = "⚠️ FLAGGED → ALERT SENT"
        else:
            decision = f"❌ {status}"

        sheet_rows.append([
            r["created_at"].strftime("%Y-%m-%d %H:%M:%S"),
            r["invoice_number"],
            "DB Export",
            r["vendor_name"],
            str(r["total_amount"]),
            status,
            decision,
            str(r["compliance_score"] or "N/A"),
            str(len(flags)),
            ", ".join(f.get("field", "") for f in flags) or "None",
            "",  # ledger id
            "",  # alert id
            "", "", ""
        ])

    log.info(f"Exporting {len(sheet_rows)-1} invoices to Google Sheet...")
    token = await get_oauth_token_from_env()

    # Clear existing and rewrite
    clear_url = (
        f"https://sheets.googleapis.com/v4/spreadsheets/{SHEET_ID}"
        f"/values/{SHEET_NAME}!A:O:clear"
    )
    async with httpx.AsyncClient(timeout=15) as client:
        await client.post(clear_url, headers={"Authorization": f"Bearer {token}"})

    write_url = (
        f"https://sheets.googleapis.com/v4/spreadsheets/{SHEET_ID}"
        f"/values/{SHEET_NAME}!A1?valueInputOption=USER_ENTERED"
    )
    async with httpx.AsyncClient(timeout=15) as client:
        r = await client.put(write_url, json={"values": sheet_rows},
                             headers={"Authorization": f"Bearer {token}",
                                      "Content-Type": "application/json"})
        if r.status_code == 200:
            log.info(f"✅ Exported {len(sheet_rows)-1} rows to Google Sheet")
        else:
            log.error(f"Failed: {r.status_code} {r.text[:200]}")


if __name__ == "__main__":
    logging.basicConfig(level=logging.INFO, format="%(asctime)s %(message)s")
    asyncio.run(export_all_from_db())
