"""
OCR Benchmark Script
════════════════════
Downloads real invoice images from:
  1. Voxel51/high-quality-invoice-images-for-ocr
  2. mychen76/invoices-and-receipts_ocr_v1

Runs Claude Vision OCR on each, then for mychen76 compares
against ground truth JSON to compute field accuracy.

Usage:
    # Run with defaults (3 samples from each dataset)
    python scripts/run_ocr_benchmark.py

    # Specify sample count and datasets
    python scripts/run_ocr_benchmark.py --dataset voxel51 --samples 5
    python scripts/run_ocr_benchmark.py --dataset mychen76 --samples 5
    python scripts/run_ocr_benchmark.py --dataset both --samples 3

    # Through orchestrator (HF: prefix routes to OCR path)
    # invoice_number = "HF:voxel51:0"   → fetches voxel51 sample #0
    # invoice_number = "HF:mychen76:2"  → fetches mychen76 sample #2 with benchmarking

Prerequisites:
    pip install httpx pydantic
    export ANTHROPIC_API_KEY=sk-ant-...
    export HF_TOKEN=hf_...      # Optional; needed only for gated datasets

Docker usage (run against running stack):
    docker-compose exec orchestrator python scripts/run_ocr_benchmark.py --samples 3
"""
from __future__ import annotations

import argparse
import asyncio
import json
import logging
import os
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent.parent))
from agents.agent1_ingestion import ingest_from_hf_dataset, HF_DATASETS

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [OCR-Bench] %(message)s"
)
log = logging.getLogger("ocr_benchmark")


async def benchmark_dataset(dataset_name: str, n_samples: int = 3):
    cfg = HF_DATASETS.get(dataset_name)
    if not cfg:
        print(f"❌ Unknown dataset: {dataset_name}. Choose from: {list(HF_DATASETS)}")
        return

    print(f"\n{'═'*65}")
    print(f"  Dataset : {cfg['repo']}")
    print(f"  Type    : {cfg['type']}")
    print(f"  Purpose : {cfg['description']}")
    print(f"  Samples : {n_samples}")
    print(f"{'═'*65}")

    results = []
    for i in range(n_samples):
        print(f"\n  ── Sample #{i} ──────────────────────────────────────────")
        try:
            result = await ingest_from_hf_dataset(dataset_name, sample_index=i)
            inv    = result["invoice"]

            print(f"  ✓ Invoice  : {inv.invoice_number}")
            print(f"    Vendor   : {inv.vendor.vendor_name}")
            print(f"    Date     : {inv.invoice_date}")
            print(f"    Total    : ${inv.total_amount:,.2f}")
            print(f"    Items    : {len(inv.line_items)}")
            for item in inv.line_items[:3]:
                print(f"      • {item.description[:45]:<45} "
                      f"qty={item.quantity} × ${item.unit_rate} = ${item.total}")
            if len(inv.line_items) > 3:
                print(f"      ... (+{len(inv.line_items)-3} more items)")

            row = {
                "sample_index":  i,
                "invoice_number": inv.invoice_number,
                "vendor":        inv.vendor.vendor_name,
                "total_amount":  float(inv.total_amount),
                "line_item_count": len(inv.line_items),
                "status":        "success"
            }

            if "benchmark_score" in result:
                bm = result["benchmark_score"]
                print(f"\n    Benchmark vs Ground Truth:")
                for field, detail in bm.items():
                    if field == "overall_accuracy_pct":
                        continue
                    icon = "✓" if detail["match"] else "✗"
                    print(f"      {icon} {field:<20} extracted={detail['extracted']!r:30} "
                          f"ground_truth={detail['ground_truth']!r}")
                print(f"\n    Overall Field Accuracy: {bm['overall_accuracy_pct']}%")
                row["accuracy_pct"] = bm["overall_accuracy_pct"]

            results.append(row)

        except RuntimeError as e:
            print(f"  ✗ Sample #{i} failed: {e}")
            results.append({"sample_index": i, "status": "failed", "error": str(e)})
        except Exception as e:
            print(f"  ✗ Sample #{i} unexpected error: {e}")
            results.append({"sample_index": i, "status": "error", "error": str(e)})

    # Summary
    successful = [r for r in results if r.get("status") == "success"]
    failed     = len(results) - len(successful)

    print(f"\n{'═'*65}")
    print(f"  SUMMARY — {dataset_name}")
    print(f"{'═'*65}")
    print(f"  Successful extractions : {len(successful)}/{n_samples}")
    print(f"  Failed                 : {failed}/{n_samples}")

    if successful:
        avg_items = sum(r["line_item_count"] for r in successful) / len(successful)
        print(f"  Avg line items/invoice : {avg_items:.1f}")
        if "accuracy_pct" in successful[0]:
            avg_acc = sum(r.get("accuracy_pct", 0) for r in successful) / len(successful)
            print(f"  Avg field accuracy     : {avg_acc:.1f}%")

    print(f"{'═'*65}")
    return results


async def main(args):
    if not os.getenv("ANTHROPIC_API_KEY"):
        print("❌ ANTHROPIC_API_KEY not set. Export it first:")
        print("   export ANTHROPIC_API_KEY=sk-ant-...")
        sys.exit(1)

    datasets = (
        ["voxel51", "mychen76"] if args.dataset == "both"
        else [args.dataset]
    )

    all_results = {}
    for ds in datasets:
        results = await benchmark_dataset(ds, n_samples=args.samples)
        if results:
            all_results[ds] = results

    # Save results to JSON
    out_path = Path(__file__).parent.parent / "docs" / "ocr_benchmark_results.json"
    out_path.parent.mkdir(exist_ok=True)
    with open(out_path, "w") as f:
        json.dump(all_results, f, indent=2, default=str)
    print(f"\n📄 Results saved to: {out_path}")


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Run OCR benchmark on HuggingFace invoice datasets")
    parser.add_argument("--dataset", default="both", choices=["voxel51", "mychen76", "both"])
    parser.add_argument("--samples", type=int, default=3, help="Number of samples per dataset")
    args = parser.parse_args()
    asyncio.run(main(args))
