"""
Preloads the ChromaDB ONNX embedding model into the shared cache volume.
Runs once before mcp_server starts — prevents mid-run model downloads
that cause MCP server restarts and payload loss.
"""
import chromadb

print("Preloading ChromaDB embedding model...")
client = chromadb.EphemeralClient()
col = client.create_collection("preload_test")
col.add(documents=["test document for model preload"], ids=["test-1"])
col.query(query_texts=["test"], n_results=1)
print("Model preloaded successfully.")
