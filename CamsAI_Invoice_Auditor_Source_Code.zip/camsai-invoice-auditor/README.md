# CamsAI — Automated Vendor Invoice Auditor
### Senior AI Systems Engineer Assessment Submission

A production-grade **multi-agent orchestration system** for automated vendor invoice auditing, built on LangGraph state machines, FastAPI MCP Server, ChromaDB vector knowledge base, and PostgreSQL.

---

## Architecture at a Glance

```
Orchestrator (LangGraph)
 ├── Agent 1: Ingestion & Extraction    → API 1 (Fetch Payload)
 ├── Agent 2: Validation & Compliance   → API 2 (ChromaDB Vector) + API 3 (Policy Rules)
 └── Agent 3: Reporting & Settlement    → API 4 (PostgreSQL Ledger) + API 5 (Email Alert)
```

**State machine routing:**
- Scenario A (compliant) → Ledger → COMPLETE
- Scenario B (anomalous) → Skip Ledger → Alert → COMPLETE
- Scenario C (malformed) → Error capture → Alert → COMPLETE

---

## Prerequisites

- **Docker Desktop** (v24+) with Docker Compose v2
- At least **4 GB RAM** allocated to Docker
- **Git**
- Optional: Python 3.11+ for running unit tests locally without Docker

---

## Quick Start (Docker — Recommended)

```bash
# 1. Clone / unzip the project
cd camsai-invoice-auditor

# 2. Configure environment
cp .env.example .env
# Edit .env — at minimum set ANTHROPIC_API_KEY
# For email alerts: set SMTP_USER, SMTP_PASS, ALERT_EMAIL
# Without SMTP config, alerts are printed to logs (fully functional for testing)

# 3. Launch everything
docker-compose up --build

# What happens automatically:
#   ① PostgreSQL starts and runs init_db.sql (schema creation)
#   ② Redis starts
#   ③ ChromaDB starts
#   ④ MCP Server starts (FastAPI on :8080)
#   ⑤ Seeder runs: seeds contracts to PostgreSQL + ChromaDB vectors + 3 invoice payloads
#   ⑥ Orchestrator runs all 3 scenarios and exits

# 4. Watch the output — you'll see all 3 scenarios process end-to-end
```

### Expected Output

```
[Orchestrator] ▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓
[Orchestrator] SCENARIO: Fully Compliant
[Agent1]       ✓ Extracted invoice: INV-SCENARIO-A | Total: $4,000.00
[Agent2]       ✓ COMPLIANT — score: 100.0 vector_match: 0.92
[Agent3]       ✓ Ledger write success: <uuid> — Invoice INV-SCENARIO-A written

[Orchestrator] SCENARIO: Anomalous Rate Deviation
[Agent1]       ✓ Extracted invoice: INV-SCENARIO-B | Total: $23,800.00
[Agent2]       ⚠ ANOMALOUS — score: 70.0 flags: 1 violations: ['UNIT_RATE_EXCEEDED:...']
[Agent3]       ✓ Alert sent via log: msg_id=alert-abc123

[Orchestrator] SCENARIO: Structural Crash / Malformed
[Agent1]       [Agent1] Pydantic validation failed: ...
[Orchestrator] ▶ ALERT node
[Agent3]       ✓ Alert sent via log: msg_id=alert-def456
```

---

## Running Tests

### Unit Tests (no Docker required)
```bash
pip install -r requirements.txt
pytest tests/test_unit.py -v
```

### Integration Tests (requires docker-compose stack running)
```bash
docker-compose up -d postgres redis chromadb mcp_server seeder
# Wait for seeder to complete, then:
pytest tests/test_integration.py -v
```

---

## MCP Server API Reference

Base URL: `http://localhost:8080`

| Method | Endpoint | Description |
|--------|----------|-------------|
| GET | `/health` | Health check |
| GET | `/api/v1/payloads` | List all seeded invoice payloads |
| GET | `/api/v1/payloads/{invoice_number}` | **API 1** — Fetch invoice payload |
| POST | `/api/v1/vector/query` | **API 2** — Query vendor contracts (ChromaDB) |
| POST | `/api/v1/policy/check` | **API 3** — Run policy compliance rules |
| POST | `/api/v1/ledger/write` | **API 4** — Write invoice to PostgreSQL ledger |
| POST | `/api/v1/notify/alert` | **API 5** — Send anomaly alert (email / log) |
| GET | `/api/v1/invoices` | List all ledger entries |
| GET | `/docs` | Auto-generated OpenAPI docs |

---

## Test Scenarios

| | Scenario A | Scenario B | Scenario C |
|--|-----------|-----------|-----------|
| **Invoice** | INV-SCENARIO-A | INV-SCENARIO-B | INV-SCENARIO-C |
| **Type** | Fully Compliant | Rate Deviation | Malformed |
| **Total** | $4,000 | $23,800 | -$9,999.99 |
| **Key Issue** | None | Line item $15k > $4k threshold | Negative total, empty items, null vendor |
| **Expected** | Ledger → COMPLETE | Skip Ledger → Alert → COMPLETE | Error → Alert → COMPLETE |

---

## Email Alert Setup (Optional)

Without SMTP config, alerts are printed beautifully to Docker logs — fully functional for testing.

To enable real email alerts:

1. Enable **2-Factor Auth** on your Gmail account
2. Go to [Google App Passwords](https://myaccount.google.com/apppasswords)
3. Generate an app password for "Mail"
4. Set in `.env`:
```env
SMTP_USER=your-email@gmail.com
SMTP_PASS=xxxx-xxxx-xxxx-xxxx   # The 16-char app password
ALERT_EMAIL=alerts@yourcompany.com
```

---

## Project Structure

```
camsai-invoice-auditor/
├── docker-compose.yml          # Full stack definition
├── .env.example                # Environment variable template
├── requirements.txt            # Root dev requirements
├── pytest.ini
│
├── mock_data/
│   ├── schemas.py              # Shared Pydantic models
│   └── seeder.py               # Data seeder (Scenarios A, B, C)
│
├── mcp_server/
│   ├── server.py               # FastAPI — all 5 APIs
│   ├── requirements.txt
│   └── Dockerfile
│
├── agents/
│   ├── orchestrator.py         # LangGraph state machine
│   ├── agent1_ingestion.py     # Agent 1: Ingest & Extract
│   ├── agent2_validation.py    # Agent 2: Validate & Comply
│   ├── agent3_settlement.py    # Agent 3: Settle & Alert
│   ├── requirements.txt
│   └── Dockerfile
│
├── scripts/
│   ├── init_db.sql             # PostgreSQL schema
│   ├── Dockerfile.seeder
│   └── seeder_requirements.txt
│
├── tests/
│   ├── test_unit.py            # Unit tests (no infra)
│   ├── test_integration.py     # Integration tests (needs stack)
│   └── conftest.py
│
└── docs/
    └── DESIGN_DOCUMENT.md      # Production & Scale design
```

---

## Design Document

See [`docs/DESIGN_DOCUMENT.md`](docs/DESIGN_DOCUMENT.md) for the full production and scale design covering:
- Architecture diagrams
- State machine design with transition tables
- Governance (data, compliance, error)
- Observability (structured logging, audit trail, Redis state cache, metrics, tracing)
- Production scaling strategy (Kubernetes, queue-based workers, ChromaDB cluster)
- Security design
- CI/CD pipeline

---

## Scoring Alignment

| Criterion | Implementation |
|-----------|---------------|
| **System Design (35%)** | Full architecture in `DESIGN_DOCUMENT.md`; state machine diagram; governance; observability; K8s scaling plan |
| **Working Code (65%)** | All 3 agents wired via LangGraph; all 5 MCP APIs implemented; PostgreSQL + ChromaDB + Redis integrated; 3 scenarios verified; email alert with log fallback; integration + unit tests |
| **Async Python 3.11+** | `asyncio` throughout; `async def` nodes; `asyncpg` for DB; `httpx.AsyncClient` for API calls |
| **docker-compose** | Single `docker-compose up --build` runs everything end-to-end |
| **Mock data + seeder** | Automatic on startup via seeder service; all 3 required scenarios |
| **State-driven orchestrator** | LangGraph `StateGraph` with typed state, conditional edges, retry logic, error isolation |
