# CamsAI Invoice Auditor — Production & Scale Design Document

**Position:** Senior AI Systems Engineer Assessment  
**Focus:** Multi-Agent Orchestration & Enterprise MCP Infrastructure  
**Author:** Assessment Submission  
**Date:** 2025

---

## 1. System Architecture

### 1.1 High-Level Overview

```
                    ┌─────────────────────────────────────────────────────┐
                    │              CLIENT / TRIGGER SURFACE               │
                    │   (Cron, Webhook, S3 Event, Manual CLI, API call)   │
                    └──────────────────────┬──────────────────────────────┘
                                           │ invoice_number or PDF bytes
                                           ▼
                    ┌─────────────────────────────────────────────────────┐
                    │           LANGGRAPH ORCHESTRATOR (Agent Controller) │
                    │  ┌──────────┐  ┌──────────┐  ┌───────────────────┐ │
                    │  │ Agent 1  │  │ Agent 2  │  │     Agent 3       │ │
                    │  │ Ingest & │→ │ Validate │→ │ Report & Settle   │ │
                    │  │ Extract  │  │ Comply   │  │ (Ledger or Alert) │ │
                    │  └────┬─────┘  └────┬─────┘  └─────────┬─────────┘ │
                    └───────┼─────────────┼──────────────────┼───────────┘
                            │             │                   │
                   MCP Protocol (HTTP/REST — all internal)    │
                            │             │                   │
         ┌──────────────────▼─────────────▼───────────────────▼──────────┐
         │                     MCP SERVER (FastAPI)                       │
         │  ┌──────────┐ ┌──────────┐ ┌──────────┐ ┌────────┐ ┌───────┐ │
         │  │  API 1   │ │  API 2   │ │  API 3   │ │ API 4  │ │ API 5 │ │
         │  │ Payload  │ │  Vector  │ │  Policy  │ │ Ledger │ │ Notif │ │
         │  │  Fetch   │ │  Query   │ │  Check   │ │ Write  │ │ Alert │ │
         │  └────┬─────┘ └────┬─────┘ └────┬─────┘ └───┬────┘ └───┬───┘ │
         └───────┼────────────┼────────────┼────────────┼──────────┼─────┘
                 │            │            │            │          │
         ┌───────▼──┐  ┌──────▼───┐       │  ┌─────────▼──┐  ┌───▼────┐
         │  Redis   │  │ ChromaDB │       │  │ PostgreSQL │  │  SMTP  │
         │ (State   │  │ (Vector  │       │  │  (Ledger   │  │ (Email │
         │  Cache)  │  │   KB)    │       │  │    DB)     │  │ Relay) │
         └──────────┘  └──────────┘       │  └────────────┘  └────────┘
                                          │
                               ┌──────────▼──────────┐
                               │  Rule Engine (pure   │
                               │  Python, no ML dep)  │
                               └─────────────────────┘
```

### 1.2 Component Responsibilities

| Component | Role | Technology |
|-----------|------|------------|
| **LangGraph Orchestrator** | State-machine DAG controlling agent execution order, routing, and retry | Python 3.11, LangGraph 0.2 |
| **Agent 1 — Ingestion** | Fetches raw payload; parses into typed InvoicePayload; handles OCR output | asyncio, Pydantic v2 |
| **Agent 2 — Validation** | Queries vendor contracts from ChromaDB; runs policy rules via API 3 | asyncio, ChromaDB SDK |
| **Agent 3 — Settlement** | Writes compliant invoices to ledger; sends alerts for anomalous ones | asyncio, asyncpg, smtplib |
| **MCP Server** | Central API hub with 5 endpoints; decouples agents from data stores | FastAPI, uvicorn |
| **PostgreSQL** | Persistent ledger: invoices, line items, contracts, audit events | PostgreSQL 15, asyncpg |
| **ChromaDB** | Vector knowledge base for contract similarity search | ChromaDB 0.5, cosine similarity |
| **Redis** | Orchestrator state persistence, TTL-based cache | Redis 7 |

---

## 2. State Machine Design

### 2.1 Orchestrator State Enum

```
INGESTING  →  VALIDATING  →  COMPLIANT  →  SETTLING  →  COMPLETE
                          ↘  ANOMALOUS  →  ALERTING  ↗
                          ↘  ERROR                   ↗
```

### 2.2 State Transition Table

| From State | Condition | To State | Agent Triggered |
|------------|-----------|----------|-----------------|
| INGESTING | Payload parsed OK | VALIDATING | Agent 2 |
| INGESTING | 404 / parse error | ERROR | Agent 3 (alert) |
| INGESTING | Transient network err + retries left | INGESTING (retry) | Agent 1 |
| VALIDATING | All policy rules pass | COMPLIANT | Agent 3 (settle) |
| VALIDATING | Any policy violation | ANOMALOUS | Agent 3 (alert) |
| VALIDATING | Agent 2 crash | ERROR | Agent 3 (alert) |
| COMPLIANT | Ledger write OK | COMPLETE | — |
| COMPLIANT | Ledger write fails | ERROR | Agent 3 (alert) |
| ANOMALOUS | Alert sent | COMPLETE | — |
| ERROR | Alert sent | COMPLETE | — |

### 2.3 LangGraph Node Wiring

```python
graph.add_edge(START, "ingest")
graph.add_conditional_edges("ingest",   route_after_ingest,   {...})
graph.add_conditional_edges("validate", route_after_validate, {...})
graph.add_conditional_edges("settle",   route_after_settle,   {...})
graph.add_edge("alert", END)
```

**Key design decisions:**
- `alert` is the single error-drain node (all failure paths converge here)
- State is immutable per node invocation — each node returns a new state dict
- Retry logic checks for transient error signatures ("connection error", "timeout") before routing to ERROR
- Max 3 retries configurable per `GraphState.max_retries`

---

## 3. Governance

### 3.1 Data Governance

| Concern | Implementation |
|---------|----------------|
| **PII handling** | Vendor contact emails stored encrypted at rest (PostgreSQL `pgcrypto` in prod) |
| **Audit trail** | Every agent action writes to `audit_events` table with agent name, state, timestamp |
| **Data lineage** | `raw_payload` column preserves original ingest bytes; derived fields traceable |
| **Retention** | Invoices retained 7 years (configurable via scheduled PostgreSQL archival job) |
| **Access control** | MCP Server runs with least-privilege DB user; read/write split at connection pool level |

### 3.2 Compliance Governance

| Rule | Threshold | Source |
|------|-----------|--------|
| Max unit rate per line item | $4,000 | ChromaDB contract KB (vendor-specific) |
| Max invoice total | $50,000 | ChromaDB contract KB (vendor-specific) |
| Line item sum must match total | ± $0.01 | API 3 rule engine |
| Negative values | 0 | API 3 rule engine |
| Empty line items | Must have ≥ 1 | Pydantic validator (Agent 1) |

Policy thresholds are **vendor-specific** — retrieved from ChromaDB and applied dynamically. The rule engine in API 3 accepts contract context from API 2, so contracts with higher approved limits are honoured automatically without code changes.

### 3.3 Error Governance

```
Error Category          │ Detection Point  │ Recovery Strategy
────────────────────────┼──────────────────┼──────────────────────────────
Structural parse error  │ Agent 1 (Pydantic)│ Immediate ERROR → alert, no retry
Network transient       │ httpx timeout    │ Exponential backoff, max 3 retries
Policy violation        │ API 3            │ Route to ANOMALOUS → alert, skip ledger
Ledger write failure    │ Agent 3          │ Route to ERROR → alert
Notification failure    │ API 5            │ Log only, mark COMPLETE (non-blocking)
ChromaDB unavailable    │ Agent 2          │ Proceed with default policy thresholds
```

---

## 4. Observability

### 4.1 Structured Logging

Every log line follows this format:
```
2024-03-15 10:23:45 [Agent2-Validation] INFO — [Agent2] ✓ COMPLIANT — score: 100.0 vector_match: 0.92
```

Log levels:
- `INFO` — normal flow events (agent start/end, state transitions)
- `WARNING` — anomaly flags, retry attempts, fallback mode activation  
- `ERROR` — unrecoverable failures, API errors with full context

### 4.2 Audit Events Table

Every significant action writes a row to `audit_events`:
```sql
agent: "Agent2-Validation"
state: "COMPLIANT"
event_type: "LEDGER_WRITE"
payload: { "status": "approved", "compliance_score": 100.0 }
```

Query all events for an invoice:
```sql
SELECT agent, state, event_type, payload, created_at
FROM audit_events
WHERE invoice_id = $1
ORDER BY created_at;
```

### 4.3 Redis State Cache

After each orchestration run, the final `GraphState` is written to Redis with a 1-hour TTL:
```
KEY: invoice:state:{invoice_number}
VALUE: JSON-serialised GraphState
TTL: 3600 seconds
```

This enables a lightweight status API to be built on top without hitting PostgreSQL.

### 4.4 Metrics (Production Extension)

| Metric | Type | Label |
|--------|------|-------|
| `invoice_processed_total` | Counter | scenario, final_state |
| `invoice_compliance_score` | Histogram | vendor_id |
| `agent_latency_seconds` | Histogram | agent_name |
| `anomaly_flags_total` | Counter | field, severity |
| `api_request_duration_seconds` | Histogram | api_endpoint |

**Recommended stack:** Prometheus + Grafana, with scrape target on MCP Server `/metrics` endpoint (add `prometheus-fastapi-instrumentator`).

### 4.5 Distributed Tracing (Production)

Add OpenTelemetry to each agent node:
```python
from opentelemetry import trace
tracer = trace.get_tracer("camsai.agent1")

async def ingest_and_extract(state):
    with tracer.start_as_current_span("agent1.ingest"):
        ...
```

Export to Jaeger or Datadog APM for end-to-end request tracing across agents.

---

## 5. Production Scale Design

### 5.1 Horizontal Scaling

```
                    Load Balancer (ALB / nginx)
                           │
              ┌────────────┼────────────┐
              ▼            ▼            ▼
         [Worker 1]   [Worker 2]   [Worker 3]    ← Orchestrator pods
              │            │            │
              └────────────┼────────────┘
                           │
                    [MCP Server]     ← 3–5 replicas behind internal LB
                           │
              ┌────────────┼──────────────┐
              ▼            ▼              ▼
         [Postgres     [ChromaDB      [Redis
          Primary +     Cluster]       Sentinel]
          Read Replica]
```

### 5.2 Queue-Based Decoupling (High Volume)

For >1,000 invoices/day, replace direct orchestrator invocation with a queue:

```
Invoice Trigger → SQS/Kafka → Orchestrator Worker Pool → MCP Server
```

```python
# Worker pool pattern
async def worker(queue: asyncio.Queue):
    while True:
        invoice_number = await queue.get()
        await run_orchestrator(invoice_number)
        queue.task_done()

# Spin up N workers
workers = [asyncio.create_task(worker(queue)) for _ in range(CONCURRENCY)]
```

### 5.3 ChromaDB at Scale

- **Local/dev:** Single ChromaDB container (current setup)
- **Production:** ChromaDB Cloud or self-hosted cluster with replication
- **Alternative:** Replace with pgvector (extension on existing PostgreSQL) to eliminate separate service
- Contract embeddings updated nightly via scheduled job when new vendor agreements are signed

### 5.4 Estimated Capacity

| Configuration | Throughput | Latency (p95) |
|---------------|-----------|---------------|
| Single docker-compose | ~5 invoices/min | ~2s |
| 3 orchestrator workers + scaled MCP | ~100 invoices/min | ~1.5s |
| Queue-based + 10 workers | ~500 invoices/min | ~2s |
| Full Kubernetes deployment | ~2,000 invoices/min | ~1s |

---

## 6. Security Design

| Layer | Control |
|-------|---------|
| **Network** | Services communicate over Docker internal network only; no external exposure except MCP port |
| **Auth** | MCP Server protected by API key header (`X-API-Key`) in production; JWT for human dashboard |
| **Secrets** | All credentials via environment variables; in prod use AWS Secrets Manager / Vault |
| **DB** | `auditor` user has INSERT/SELECT/UPDATE only; no DROP/DDL permissions |
| **Email** | SMTP credentials never logged; masked in audit events |
| **Input** | All inputs validated via Pydantic v2 before any DB write; parameterised queries only |

---

## 7. Deployment

### 7.1 Local (this submission)
```bash
cp .env.example .env          # add ANTHROPIC_API_KEY + optional SMTP config
docker-compose up --build     # spins up everything, seeds data, runs all 3 scenarios
```

### 7.2 Production (Kubernetes)

```yaml
# Minimal K8s architecture
services:
  - Deployment: mcp-server (3 replicas, HPA on CPU)
  - Deployment: orchestrator-worker (5 replicas)
  - StatefulSet: postgresql (primary + 1 read replica)
  - StatefulSet: redis (sentinel mode)
  - Deployment: chromadb (2 replicas)

ingress:
  - MCP Server internal ClusterIP only
  - Dashboard on LoadBalancer with TLS
```

### 7.3 CI/CD Pipeline

```
Push → GitHub Actions:
  1. pytest tests/test_unit.py  (no infra needed)
  2. docker-compose up (ephemeral test env)
  3. pytest tests/test_integration.py
  4. docker build + push to ECR
  5. kubectl rollout deploy/mcp-server
  6. kubectl rollout deploy/orchestrator-worker
```

---

## 8. Scenario Expected Outcomes

| Scenario | Invoice | Expected Route | Final State | Ledger? | Alert? |
|----------|---------|---------------|-------------|---------|--------|
| **A** | Compliant, $4k total | INGESTING → VALIDATING → COMPLIANT → SETTLING → COMPLETE | COMPLETE | ✅ Yes | ❌ No |
| **B** | Rate deviation ($15k item) | INGESTING → VALIDATING → ANOMALOUS → ALERTING → COMPLETE | COMPLETE | ❌ Skipped | ✅ Yes |
| **C** | Malformed payload | INGESTING → ERROR → ALERTING → COMPLETE | COMPLETE | ❌ Skipped | ✅ Yes |

---

## 9. Technology Choices & Rationale

| Choice | Alternative Considered | Reason |
|--------|----------------------|--------|
| **LangGraph** | Raw asyncio DAG | Built-in state management, conditional edges, observability hooks |
| **ChromaDB** | pgvector, Pinecone | Zero-config local deployment; easy Docker integration |
| **FastAPI** | Flask, gRPC | Async native, auto-OpenAPI docs, Pydantic integration |
| **asyncpg** | SQLAlchemy async | Lowest latency PostgreSQL driver; no ORM overhead for audit writes |
| **Pydantic v2** | dataclasses | Validation, serialisation, and schema generation in one library |
| **Redis** | In-memory dict | Survives orchestrator restarts; TTL-native for state expiry |
