"""
Agent 1: Ingestion & Extraction
─────────────────────────────────
Two ingestion modes:
  1. STRUCTURED: Fetch pre-parsed JSON from MCP API 1 (mock scenarios A/B/C)
  2. OCR IMAGE:  Download invoice image from HuggingFace, run Claude Vision OCR

Datasets:
  - Voxel51/high-quality-invoice-images-for-ocr  (8,181 synthetic invoices)
  - mychen76/invoices-and-receipts_ocr_v1        (1,489 real invoices + ground truth)

Invoice number routing:
  "INV-SCENARIO-A"   → structured JSON from MCP API 1
  "HF:voxel51:3"     → Voxel51 image #3 → Claude Vision → InvoicePayload
  "HF:mychen76:0"    → mychen76 image #0 → Claude Vision → benchmark vs ground truth

State transitions:
  INGESTING → VALIDATING  (success)
  INGESTING → ERROR       (failure)
"""
from __future__ import annotations

import base64
import json
import logging
import os
from decimal import Decimal, InvalidOperation
from pathlib import Path
from typing import Optional

import httpx
from pydantic import ValidationError

import sys
sys.path.insert(0, str(Path(__file__).parent.parent))
from mock_data.schemas import (
    GraphState, InvoicePayload, LineItem, OrchestratorState, VendorInfo
)

log = logging.getLogger("Agent1-Ingestion")

MCP_URL           = os.getenv("MCP_URL", "http://localhost:8080")
ANTHROPIC_API_KEY = os.getenv("ANTHROPIC_API_KEY", "")
HF_TOKEN          = os.getenv("HF_TOKEN", "")

HF_DATASETS = {
    "voxel51": {
        "hf_id": "Voxel51/high-quality-invoice-images-for-ocr",
        "type": "image_only",
        "description": "8,181 synthetic invoice images"
    },
    "mychen76": {
        "hf_id": "mychen76/invoices-and-receipts_ocr_v1",
        "type": "image_with_ground_truth",
        "description": "1,489 real invoices with ground truth JSON"
    }
}


# ── Decimal coercion ──────────────────────────────────────────────────────────

def _coerce_decimal(val) -> Decimal:
    if val is None:
        return Decimal("0")
    try:
        cleaned = str(val).replace(",", "").replace("$", "").strip()
        return Decimal(cleaned)
    except InvalidOperation:
        return Decimal("0")


# ── Raw dict → InvoicePayload ─────────────────────────────────────────────────

def _parse_raw_to_invoice(raw: dict) -> InvoicePayload:
    vendor_raw = raw.get("vendor", {})
    if isinstance(vendor_raw, str):
        vendor_raw = {"vendor_name": vendor_raw, "vendor_id": "UNKNOWN"}

    vendor = VendorInfo(
        vendor_id     = str(vendor_raw.get("vendor_id") or "UNKNOWN"),
        vendor_name   = str(vendor_raw.get("vendor_name") or "Unknown Vendor"),
        contact_email = vendor_raw.get("contact_email"),
        address       = vendor_raw.get("address"),
    )

    raw_items  = raw.get("line_items", [])
    line_items = []
    for item in raw_items:
        qty   = _coerce_decimal(item.get("quantity", 1))
        rate  = _coerce_decimal(
            item.get("unit_rate") or item.get("unit_price") or item.get("rate", 0)
        )
        total = _coerce_decimal(
            item.get("total") or item.get("amount") or (qty * rate)
        )
        line_items.append(LineItem(
            description = str(item.get("description") or item.get("name") or "Unknown item"),
            quantity    = qty,
            unit_rate   = rate,
            total       = total,
            category    = str(item.get("category") or "general"),
        ))

    total_amount = _coerce_decimal(
        raw.get("total_amount") or raw.get("total") or raw.get("amount_due")
    )

    # If empty line items, add a placeholder so Pydantic does not crash.
    # Policy check (API 3) will catch and flag EMPTY_LINE_ITEMS.
    if not line_items:
        line_items = [LineItem(
            description="No line items extracted",
            quantity=Decimal("1"),
            unit_rate=Decimal("0"),
            total=Decimal("0"),
            category="unknown"
        )]

    return InvoicePayload(
        invoice_number = str(raw.get("invoice_number") or raw.get("invoice_id") or "UNKNOWN"),
        vendor         = vendor,
        invoice_date   = raw.get("invoice_date") or raw.get("date") or "2024-01-01",
        due_date       = raw.get("due_date"),
        currency       = raw.get("currency", "USD"),
        line_items     = line_items,
        total_amount   = total_amount,
        notes          = raw.get("notes"),
        scenario       = raw.get("scenario"),
    )


# ── HuggingFace image fetch ───────────────────────────────────────────────────

def _fetch_hf_image_sync(dataset_name: str, sample_index: int) -> Optional[dict]:
    """
    Fetch one image from HuggingFace using the datasets library.
    This supports both Voxel51 (FiftyOne format) and mychen76 datasets.
    Runs synchronously — called via asyncio.to_thread from async context.
    """
    from datasets import load_dataset
    import io

    cfg = HF_DATASETS.get(dataset_name)
    if not cfg:
        raise ValueError(f"Unknown dataset: {dataset_name}")

    hf_id = cfg["hf_id"]

    # Load one sample via streaming (no full download needed)
    ds = load_dataset(
        hf_id,
        split="train",
        streaming=True,
        token=HF_TOKEN if HF_TOKEN else None
    )

    # Skip to the required index
    sample = None
    for i, row in enumerate(ds):
        if i == sample_index:
            sample = row
            break

    if sample is None:
        raise RuntimeError(f"Sample #{sample_index} not found in {dataset_name}")

    result = {"dataset": dataset_name, "sample_index": sample_index}

    # Check for pre-extracted annotation FIRST (Voxel51 FiftyOne format)
    # Voxel51 has both image + json_annotation — we prefer json_annotation
    # to avoid unnecessary Claude Vision API calls
    json_ann = sample.get("json_annotation")
    ocr_text = sample.get("ocr_text")

    if json_ann or ocr_text:
        # Text-only path — no Claude Vision needed
        result["text_only"]       = True
        result["ocr_text"]        = ocr_text
        result["json_annotation"]  = json_ann
        result["filepath"]         = sample.get("filepath", "")
        result["image_url"]        = f"hf://{hf_id}/train/{sample_index}"
    else:
        # Image path — need Claude Vision OCR (mychen76)
        img = sample.get("image") or sample.get("img")
        if img is not None:
            buf = io.BytesIO()
            if hasattr(img, "save"):
                img.save(buf, format="JPEG")
            else:
                buf.write(bytes(img))
            result["image_bytes"] = buf.getvalue()
            result["image_url"]   = f"hf://{hf_id}/train/{sample_index}"
        else:
            raise RuntimeError(f"No image or text data in {dataset_name} sample #{sample_index}")

    # Ground truth (mychen76)
    gt = sample.get("ground_truth")
    if gt:
        if isinstance(gt, str):
            try:
                gt = json.loads(gt)
            except Exception:
                pass
        result["ground_truth"] = gt

    # For Voxel51 annotated samples — json_annotation is ground truth
    json_ann = sample.get("json_annotation")
    if json_ann and "ground_truth" not in result:
        try:
            result["ground_truth"] = json.loads(json_ann) if isinstance(json_ann, str) else json_ann
        except Exception:
            pass

    return result


async def _fetch_hf_image(dataset_name: str, sample_index: int) -> Optional[dict]:
    """Async wrapper around the sync HF fetch using thread pool."""
    import asyncio
    return await asyncio.to_thread(_fetch_hf_image_sync, dataset_name, sample_index)


# ── Claude Vision OCR ─────────────────────────────────────────────────────────

CLAUDE_OCR_SYSTEM = """You are an expert invoice OCR parser.
Given an invoice image, extract all structured data and return ONLY valid JSON.
No preamble, no markdown fences, no explanation — just the JSON object.

Required JSON schema:
{
  "invoice_number": "string or null",
  "vendor": {
    "vendor_id": "AUTO-{first 6 chars of vendor name uppercased}",
    "vendor_name": "string",
    "contact_email": "string or null",
    "address": "string or null"
  },
  "invoice_date": "YYYY-MM-DD",
  "due_date": "YYYY-MM-DD or null",
  "currency": "USD",
  "line_items": [
    {
      "description": "string",
      "quantity": number,
      "unit_rate": number,
      "total": number,
      "category": "string"
    }
  ],
  "total_amount": number,
  "notes": "string or null"
}

Rules:
- Extract all line items with quantities, unit rates, and totals.
- If unit rate missing, compute as total / quantity.
- If quantity implied as 1, set quantity=1.0 and unit_rate = line total.
- Parse currency symbols and commas: "$1,234.56" → 1234.56.
- Dates must be YYYY-MM-DD. If only month/year visible, use first day of month.
- If invoice_number not visible, generate as "OCR-{vendor initials}-{date}".
- category: classify each line as one of: compute, storage, network, consulting, software, support, services, general."""


async def _ocr_with_claude(image_bytes: bytes, media_type: str = "image/jpeg") -> Optional[dict]:
    """Send image to Claude Vision and get structured invoice JSON back."""
    if not ANTHROPIC_API_KEY:
        raise RuntimeError("ANTHROPIC_API_KEY not set — cannot run Claude Vision OCR")

    b64 = base64.standard_b64encode(image_bytes).decode("utf-8")

    payload = {
        "model": "claude-sonnet-4-6",
        "max_tokens": 2000,
        "system": CLAUDE_OCR_SYSTEM,
        "messages": [{
            "role": "user",
            "content": [
                {
                    "type": "image",
                    "source": {
                        "type": "base64",
                        "media_type": media_type,
                        "data": b64
                    }
                },
                {
                    "type": "text",
                    "text": "Extract all invoice fields from this image and return valid JSON only."
                }
            ]
        }]
    }

    async with httpx.AsyncClient(timeout=120) as client:
        r = await client.post(
            "https://api.anthropic.com/v1/messages",
            headers={
                "x-api-key":         ANTHROPIC_API_KEY,
                "anthropic-version": "2023-06-01",
                "content-type":      "application/json"
            },
            json=payload
        )
        r.raise_for_status()
        resp = r.json()

    raw_text = resp["content"][0]["text"].strip()

    # Strip markdown fences if model adds them
    if raw_text.startswith("```"):
        lines = raw_text.split("\n")
        raw_text = "\n".join(lines[1:-1] if lines[-1] == "```" else lines[1:])

    return json.loads(raw_text.strip())


# ── OCR benchmark scoring ─────────────────────────────────────────────────────

def _score_ocr_vs_ground_truth(extracted: dict, ground_truth: dict) -> dict:
    """Score extracted fields against mychen76 ground truth."""
    gt_parse = ground_truth.get("gt_parse", ground_truth)
    fields   = ["invoice_number", "total_amount", "invoice_date"]
    results  = {}
    matched  = 0

    for field in fields:
        gt_val  = str(gt_parse.get(field, "") or "").strip().lower()
        ext_val = str(extracted.get(field, "") or "").strip().lower()

        if field == "total_amount":
            try:
                gt_n  = float(gt_val.replace(",", "").replace("$", ""))
                ex_n  = float(ext_val.replace(",", "").replace("$", ""))
                match = abs(gt_n - ex_n) < 0.02
            except Exception:
                match = gt_val == ext_val
        else:
            match = gt_val == ext_val or (gt_val and gt_val in ext_val)

        results[field] = {"ground_truth": gt_val, "extracted": ext_val, "match": match}
        if match:
            matched += 1

    results["overall_accuracy_pct"] = round((matched / len(fields)) * 100, 1)
    return results



# ── Voxel51 annotation parser ─────────────────────────────────────────────────

def _parse_voxel51_annotation(json_annotation, ocr_text: str, sample_index: int) -> Optional[dict]:
    """
    Parse Voxel51 structured JSON annotation into our invoice schema.
    Voxel51 format:
    {
      "invoice": {
        "seller_name": ..., "client_name": ...,
        "invoice_number": ..., "invoice_date": ..., "due_date": ...
      },
      "items": [{"description": ..., "quantity": ..., "unit_price": ..., "total": ...}],
      "total_amount": ..., "tax_amount": ...
    }
    """
    if not json_annotation:
        return None

    try:
        if isinstance(json_annotation, str):
            ann = json.loads(json_annotation)
        else:
            ann = json_annotation

        inv = ann.get("invoice", {})
        items = ann.get("items", [])

        vendor_name = inv.get("seller_name") or inv.get("vendor_name") or "Unknown Vendor"
        vendor_id   = "AUTO-" + vendor_name[:6].upper().replace(" ", "")

        # Parse line items
        line_items = []
        for item in items:
            desc  = str(item.get("description") or "Unknown item")
            qty   = float(str(item.get("quantity") or "1").replace(",", "") or "1")
            rate  = float(str(item.get("unit_price") or item.get("unit_rate") or "0").replace(",", "").replace("$", "") or "0")
            total = float(str(item.get("total") or item.get("amount") or "0").replace(",", "").replace("$", "") or "0")
            if rate == 0 and total > 0 and qty > 0:
                rate = total / qty
            line_items.append({
                "description": desc,
                "quantity": qty,
                "unit_rate": rate,
                "total": total,
                "category": "general"
            })

        total_str = str(ann.get("total_amount") or ann.get("total") or "0")
        total_amount = float(total_str.replace(",", "").replace("$", "") or "0")

        # Date parsing
        raw_date = inv.get("invoice_date") or inv.get("date") or "2024-01-01"
        try:
            from datetime import datetime
            for fmt in ["%m/%d/%Y", "%Y-%m-%d", "%d/%m/%Y", "%B %d, %Y"]:
                try:
                    parsed = datetime.strptime(raw_date, fmt)
                    raw_date = parsed.strftime("%Y-%m-%d")
                    break
                except Exception:
                    continue
        except Exception:
            raw_date = "2024-01-01"

        inv_num = (inv.get("invoice_number") or
                   f"VOX-{sample_index:05d}")

        return {
            "invoice_number": inv_num,
            "vendor": {
                "vendor_id":     vendor_id,
                "vendor_name":   vendor_name,
                "contact_email": None,
                "address":       inv.get("seller_address")
            },
            "invoice_date": raw_date,
            "due_date":     inv.get("due_date"),
            "currency":     "USD",
            "line_items":   line_items,
            "total_amount": total_amount,
            "notes":        None
        }
    except Exception as e:
        log.warning(f"[Agent1] Voxel51 annotation parse failed: {e}")
        return None


# ── HuggingFace full pipeline ─────────────────────────────────────────────────

async def ingest_from_hf_dataset(dataset_name: str, sample_index: int = 0) -> dict:
    """
    Full OCR pipeline for one HuggingFace sample.
    Supports two modes:
      - Text-only: Voxel51 samples with pre-extracted JSON annotations (no API call needed)
      - Image: mychen76 samples with PIL images (Claude Vision OCR)
    """
    log.info(f"[Agent1-OCR] {dataset_name} sample #{sample_index}")

    # 1. Fetch from HuggingFace via datasets library
    sample = await _fetch_hf_image(dataset_name, sample_index)
    if not sample:
        raise RuntimeError(f"Could not fetch {dataset_name} sample #{sample_index}")

    ocr_raw = None

    # ── Text-only path: Voxel51 pre-extracted JSON annotations ───────────────
    if sample.get("text_only"):
        log.info(f"[Agent1-OCR] Using pre-extracted annotation (no Claude Vision needed)")
        ocr_raw = _parse_voxel51_annotation(
            sample.get("json_annotation"),
            sample.get("ocr_text"),
            sample_index
        )
        if not ocr_raw:
            # Fall back to ocr_text if json_annotation is missing
            if sample.get("ocr_text"):
                ocr_raw = {
                    "invoice_number": f"VOX-{sample_index:05d}",
                    "vendor": {"vendor_id": "UNKNOWN", "vendor_name": "Unknown Vendor"},
                    "invoice_date": "2024-01-01",
                    "due_date": None,
                    "currency": "USD",
                    "line_items": [],
                    "total_amount": 0,
                    "notes": sample["ocr_text"][:200]
                }
            else:
                raise RuntimeError(f"No annotation data in Voxel51 sample #{sample_index}")

    # ── Image path: Claude Vision OCR ─────────────────────────────────────────
    elif "image_bytes" in sample:
        image_bytes = sample["image_bytes"]
        log.info(f"[Agent1-OCR] Image: {len(image_bytes):,} bytes — running Claude Vision")

        media_type = "image/jpeg"
        if image_bytes[:4] == b'\x89PNG':
            media_type = "image/png"

        ocr_raw = await _ocr_with_claude(image_bytes, media_type)
        if not ocr_raw:
            raise RuntimeError("Claude Vision OCR returned no data")

    else:
        raise RuntimeError(f"No image or annotation data in {dataset_name} sample #{sample_index}")

    log.info(
        f"[Agent1-OCR] Extracted: invoice={ocr_raw.get('invoice_number')} "
        f"vendor={ocr_raw.get('vendor', {}).get('vendor_name')} "
        f"total=${ocr_raw.get('total_amount')}"
    )

    # 3. Parse to InvoicePayload
    invoice = _parse_raw_to_invoice(ocr_raw)

    result = {
        "dataset":    dataset_name,
        "sample_idx": sample_index,
        "image_url":  sample.get("image_url", ""),
        "ocr_raw":    ocr_raw,
        "invoice":    invoice,
    }

    # 4. Benchmark against ground truth
    if "ground_truth" in sample:
        score = _score_ocr_vs_ground_truth(ocr_raw, sample["ground_truth"])
        result["benchmark_score"] = score
        log.info(f"[Agent1-OCR] Benchmark accuracy: {score['overall_accuracy_pct']}%")

    return result


# ── Main LangGraph node ───────────────────────────────────────────────────────

async def ingest_and_extract(state: GraphState) -> GraphState:
    """
    LangGraph node: Agent 1
    Routes by invoice_number prefix:
      HF:dataset:index → OCR pipeline
      anything else    → MCP API 1 structured JSON
    """
    invoice_number = state.invoice_number or ""

    # ── OCR path ──────────────────────────────────────────────────────────────
    if invoice_number.startswith("HF:"):
        parts        = invoice_number.split(":")
        dataset_name = parts[1] if len(parts) > 1 else "voxel51"
        sample_index = int(parts[2]) if len(parts) > 2 else 0

        log.info(f"[Agent1] OCR path: {dataset_name} sample #{sample_index}")
        try:
            result  = await ingest_from_hf_dataset(dataset_name, sample_index)
            invoice = result["invoice"]

            state.extracted_invoice  = invoice
            state.raw_payload        = result.get("ocr_raw", {})
            state.orchestrator_state = OrchestratorState.VALIDATING

            log.info(
                f"[Agent1] ✓ OCR complete: {invoice.invoice_number} | "
                f"Vendor: {invoice.vendor.vendor_name} | "
                f"Total: ${invoice.total_amount:,.2f} | "
                f"Items: {len(invoice.line_items)}"
            )

        except Exception as e:
            err = f"HF OCR ingestion failed: {e}"
            log.error(f"[Agent1] {err}")
            state.extraction_error   = err
            state.orchestrator_state = OrchestratorState.ERROR

        return state

    # ── Structured JSON path ──────────────────────────────────────────────────
    log.info(f"[Agent1] Structured path: {invoice_number}")
    try:
        async with httpx.AsyncClient(timeout=15) as client:
            resp = await client.get(f"{MCP_URL}/api/v1/payloads/{invoice_number}")
            resp.raise_for_status()
            api_response = resp.json()

        raw_payload       = api_response.get("payload", {})
        state.raw_payload = raw_payload

    except httpx.HTTPStatusError as e:
        err = (
            f"Invoice {invoice_number} not found in payload store"
            if e.response.status_code == 404
            else f"API 1 HTTP {e.response.status_code}: {e.response.text[:200]}"
        )
        log.error(f"[Agent1] {err}")
        state.extraction_error   = err
        state.orchestrator_state = OrchestratorState.ERROR
        return state

    except httpx.RequestError as e:
        err = f"API 1 connection error: {e}"
        log.error(f"[Agent1] {err}")
        state.extraction_error   = err
        state.orchestrator_state = OrchestratorState.ERROR
        return state

    try:
        invoice = _parse_raw_to_invoice(raw_payload)
        state.extracted_invoice  = invoice
        state.orchestrator_state = OrchestratorState.VALIDATING
        log.info(
            f"[Agent1] ✓ Extracted: {invoice.invoice_number} | "
            f"Vendor: {invoice.vendor.vendor_name} | "
            f"Total: ${invoice.total_amount:,.2f} | "
            f"Items: {len(invoice.line_items)}"
        )

    except ValidationError as e:
        err = f"Pydantic validation failed: {e.errors()[0]['msg']}"
        log.error(f"[Agent1] {err}")
        state.extraction_error   = err
        state.orchestrator_state = OrchestratorState.ERROR

    except Exception as e:
        err = f"Extraction error: {type(e).__name__}: {e}"
        log.error(f"[Agent1] {err}")
        state.extraction_error   = err
        state.orchestrator_state = OrchestratorState.ERROR

    return state
