"""
CamsAI Invoice Auditor — LangGraph State-Driven Orchestrator
═════════════════════════════════════════════════════════════

State machine graph:

  [START]
     │
     ▼
 [INGEST]  ──── error ──────────────────────────────────────────┐
     │                                                           │
     ▼                                                           │
 [VALIDATE] ── error ───────────────────────────────────────────┤
     │                                                           │
  ┌──┴──────────────┐                                           │
  │ compliant       │ anomalous                                  │
  ▼                 ▼                                           │
[SETTLE]       [ALERT]  ◄──────────────────────────────────────┘
  │                │
  └────────┬───────┘
           ▼
        [END]

Retry logic: up to 3 retries for transient errors (connection issues).
Error isolation: structural parse failures immediately route to ERROR without retry.

Invoice number routing:
  "INV-SCENARIO-A"   → structured JSON from MCP API 1
  "HF:voxel51:3"     → download image #3 from Voxel51 dataset, OCR via Claude Vision
  "HF:mychen76:0"    → download image #0 from mychen76 dataset, OCR + benchmark vs ground truth
"""
from __future__ import annotations

import asyncio
import logging
import os
import time
from pathlib import Path
from typing import Literal

import redis.asyncio as aioredis
from langgraph.graph import END, START, StateGraph

import sys
sys.path.insert(0, str(Path(__file__).parent.parent))
from mock_data.schemas import GraphState, OrchestratorState
from agents.agent1_ingestion    import ingest_and_extract
from agents.agent2_validation   import validate_and_check_compliance
from agents.agent3_settlement   import send_alert_notification, settle_to_ledger

# Google Sheets logger (optional — only runs if GOOGLE_SHEET_ID is set)
try:
    from scripts.sheets_logger import log_run_to_sheets
    _SHEETS_ENABLED = True
except ImportError:
    _SHEETS_ENABLED = False

log = logging.getLogger("Orchestrator")
REDIS_URL = os.getenv("REDIS_URL", "redis://localhost:6379")

# Transient errors that warrant retry (vs structural errors that don't)
_TRANSIENT_ERRORS = ("connection error", "timeout", "unreachable", "refused")


def _is_transient(err: str | None) -> bool:
    if not err:
        return False
    return any(t in err.lower() for t in _TRANSIENT_ERRORS)


# ──────────────────────────────────────────────────────────────────────────────
# Node wrappers
# ──────────────────────────────────────────────────────────────────────────────

async def node_ingest(state: GraphState) -> GraphState:
    log.info(f"[Orchestrator] ▶ INGEST | invoice={state.invoice_number}")
    state = await ingest_and_extract(state)
    log.info(f"[Orchestrator] ◀ INGEST done | state={state.orchestrator_state}")
    return state


async def node_validate(state: GraphState) -> GraphState:
    log.info(f"[Orchestrator] ▶ VALIDATE")
    state = await validate_and_check_compliance(state)
    log.info(f"[Orchestrator] ◀ VALIDATE done | state={state.orchestrator_state}")
    return state


async def node_settle(state: GraphState) -> GraphState:
    log.info(f"[Orchestrator] ▶ SETTLE")
    state = await settle_to_ledger(state)
    log.info(f"[Orchestrator] ◀ SETTLE done | state={state.orchestrator_state}")
    return state


async def node_alert(state: GraphState) -> GraphState:
    log.info(f"[Orchestrator] ▶ ALERT")
    state = await send_alert_notification(state)
    log.info(f"[Orchestrator] ◀ ALERT done | state={state.orchestrator_state}")
    return state


# ──────────────────────────────────────────────────────────────────────────────
# Conditional edge routers
# ──────────────────────────────────────────────────────────────────────────────

def route_after_ingest(state: GraphState) -> Literal["validate", "alert", "__end__"]:
    s = state.orchestrator_state
    if s == OrchestratorState.VALIDATING:
        return "validate"
    if s == OrchestratorState.ERROR:
        if state.retry_count < state.max_retries and _is_transient(state.extraction_error):
            state.retry_count += 1
            log.warning(f"[Orchestrator] Transient error — retry {state.retry_count}/{state.max_retries}")
            return "validate"
        return "alert"
    return "__end__"


def route_after_validate(state: GraphState) -> Literal["settle", "alert"]:
    if state.orchestrator_state == OrchestratorState.COMPLIANT:
        return "settle"
    return "alert"


def route_after_settle(state: GraphState) -> Literal["__end__", "alert"]:
    if state.orchestrator_state == OrchestratorState.COMPLETE:
        return "__end__"
    return "alert"


# ──────────────────────────────────────────────────────────────────────────────
# Build the LangGraph
# ──────────────────────────────────────────────────────────────────────────────

def build_graph() -> StateGraph:
    from typing import TypedDict, Any, Optional

    class _State(TypedDict, total=False):
        invoice_number: Optional[str]
        raw_payload: Optional[dict]
        extracted_invoice: Optional[Any]
        extraction_error: Optional[str]
        validation_result: Optional[Any]
        validation_error: Optional[str]
        ledger_response: Optional[Any]
        notification_response: Optional[Any]
        settlement_error: Optional[str]
        orchestrator_state: OrchestratorState
        retry_count: int
        max_retries: int

    def _wrap(fn):
        async def wrapped(state_dict: dict) -> dict:
            gs = GraphState(**state_dict)
            gs = await fn(gs)
            return gs.model_dump()
        return wrapped

    def _route_ingest(state_dict: dict) -> str:
        return route_after_ingest(GraphState(**state_dict))

    def _route_validate(state_dict: dict) -> str:
        return route_after_validate(GraphState(**state_dict))

    def _route_settle(state_dict: dict) -> str:
        return route_after_settle(GraphState(**state_dict))

    graph = StateGraph(dict)
    graph.add_node("ingest",   _wrap(node_ingest))
    graph.add_node("validate", _wrap(node_validate))
    graph.add_node("settle",   _wrap(node_settle))
    graph.add_node("alert",    _wrap(node_alert))

    graph.add_edge(START, "ingest")
    graph.add_conditional_edges("ingest",   _route_ingest,   {"validate": "validate", "alert": "alert", "__end__": END})
    graph.add_conditional_edges("validate", _route_validate, {"settle": "settle", "alert": "alert"})
    graph.add_conditional_edges("settle",   _route_settle,   {"__end__": END, "alert": "alert"})
    graph.add_edge("alert", END)

    return graph.compile()


# ──────────────────────────────────────────────────────────────────────────────
# Orchestrator runner
# ──────────────────────────────────────────────────────────────────────────────

async def run_orchestrator(invoice_number: str) -> dict:
    graph = build_graph()

    initial_state = GraphState(
        invoice_number     = invoice_number,
        orchestrator_state = OrchestratorState.INGESTING,
        retry_count        = 0,
        max_retries        = 3
    ).model_dump()

    log.info(f"\n{'═'*60}")
    log.info(f"  🚀 START: {invoice_number}")
    log.info(f"{'═'*60}")

    _t_start = time.time()
    final_state_dict = await graph.ainvoke(initial_state)
    _processing_time = time.time() - _t_start
    final_state = GraphState(**final_state_dict)

    log.info(f"\n{'═'*60}")
    log.info(f"  ✅ COMPLETE: {invoice_number}")
    log.info(f"  Final State : {final_state.orchestrator_state}")
    if final_state.validation_result:
        log.info(f"  Compliance  : {final_state.validation_result.compliance_score:.1f}/100")
        log.info(f"  Flags       : {len(final_state.validation_result.anomaly_flags)}")
    if final_state.ledger_response:
        log.info(f"  Ledger ID   : {final_state.ledger_response.invoice_id}")
    if final_state.notification_response:
        log.info(f"  Alert sent  : {final_state.notification_response.channel} ({final_state.notification_response.message_id})")
    if final_state.extraction_error:
        log.error(f"  Extract Err : {final_state.extraction_error}")
    if final_state.validation_error:
        log.error(f"  Validate Err: {final_state.validation_error}")
    if final_state.settlement_error:
        log.error(f"  Settle Err  : {final_state.settlement_error}")
    log.info(f"{'═'*60}\n")

    # Persist to Redis
    try:
        import json
        redis = await aioredis.from_url(REDIS_URL, decode_responses=True)
        await redis.setex(
            f"invoice:state:{invoice_number}",
            3600,
            json.dumps(final_state_dict, default=str)
        )
        await redis.close()
    except Exception as e:
        log.warning(f"[Orchestrator] Redis persist failed: {e}")

    # Log to Google Sheets (non-blocking)
    if _SHEETS_ENABLED and os.getenv("GOOGLE_SHEET_ID"):
        try:
            await log_run_to_sheets(final_state_dict, _processing_time)
        except Exception as e:
            log.warning(f"[Orchestrator] Sheets log failed: {e}")

    return final_state_dict


# ──────────────────────────────────────────────────────────────────────────────
# Entrypoint: runs all scenarios
# ──────────────────────────────────────────────────────────────────────────────

async def main():
    logging.basicConfig(
        level=logging.INFO,
        format="%(asctime)s [%(name)s] %(levelname)s — %(message)s"
    )

    # ── Part 1: Core mock-data scenarios (always run) ─────────────────────────
    scenarios = [
        ("INV-SCENARIO-A", "Fully Compliant — route to Ledger"),
        ("INV-SCENARIO-B", "Anomalous Rate Deviation — skip Ledger, alert"),
        ("INV-SCENARIO-C", "Structural Crash — error capture, alert"),
    ]

    # ── Part 2: HuggingFace dataset OCR scenarios (10 images, 5 per dataset) ──
    # Runs when ANTHROPIC_API_KEY is set.
    # Uses HF Datasets Server API — no disk, no pip install needed.
    # HF_TOKEN is optional; set it in .env if you hit 403 errors.
    #
    # To disable OCR run (faster): set RUN_OCR_BENCHMARK=false in .env
    run_ocr = os.getenv("RUN_OCR_BENCHMARK", "true").lower() != "false"
    if run_ocr and os.getenv("ANTHROPIC_API_KEY"):
        # Default: 5 samples per dataset = 10 images total.
        # Override with env vars to run more/fewer:
        #   VOXEL51_SAMPLES=50   → run 50 images from Voxel51
        #   MYCHEN76_SAMPLES=50  → run 50 images from mychen76
        # To run ENTIRE datasets: set to 1489 (mychen76 annotated) or 8181 (voxel51 full)
        voxel51_n  = int(os.getenv("VOXEL51_SAMPLES",  "500"))
        mychen76_n = int(os.getenv("MYCHEN76_SAMPLES", "500"))

        for i in range(voxel51_n):
            scenarios.append((
                f"HF:voxel51:{i}",
                f"OCR — Voxel51 sample #{i} (tabular layout, currency parsing)"
            ))
        for i in range(mychen76_n):
            scenarios.append((
                f"HF:mychen76:{i}",
                f"OCR — mychen76 sample #{i} (entity recognition + ground truth)"
            ))
    elif run_ocr and not os.getenv("ANTHROPIC_API_KEY"):
        log.warning("ANTHROPIC_API_KEY not set — skipping OCR benchmark (set it in .env to enable)")

    # ── Run all scenarios ─────────────────────────────────────────────────────
    results = []
    results_full = []   # full state dicts for CSV export
    for inv_num, desc in scenarios:
        log.info(f"\n{'▓'*60}")
        log.info(f"  SCENARIO : {desc}")
        log.info(f"  Invoice  : {inv_num}")
        log.info(f"{'▓'*60}")

        result = await run_orchestrator(inv_num)
        results_full.append(result)
        results.append({
            "invoice":          inv_num,
            "scenario":         desc,
            "final_state":      result.get("orchestrator_state"),
            "compliance_score": (
                result.get("validation_result", {}).get("compliance_score")
                if result.get("validation_result") else None
            )
        })
        # Write to CSV immediately after each invoice (not at end)
        await export_csv([result])
        await asyncio.sleep(0.5)

    # ── Final summary ─────────────────────────────────────────────────────────
    log.info("\n" + "═"*65)
    log.info("  FINAL RESULTS SUMMARY")
    log.info("═"*65)
    for r in results:
        log.info(f"  [{r['final_state']:<10}] {r['invoice']}")
        log.info(f"              {r['scenario']}")
        if r["compliance_score"] is not None:
            log.info(f"              Compliance score: {r['compliance_score']}/100")
    log.info("═"*65)

    # How to run all images (printed to logs at the end)
    log.info("")
    log.info("  To run ALL images from each dataset (not just 10 samples),")
    log.info("  see the comment block in agents/orchestrator.py main() —")
    log.info("  change range(5) to range(N) where N is the number you want,")
    log.info("  or set VOXEL51_SAMPLES and MYCHEN76_SAMPLES env vars.")
    log.info("═"*65)

    # CSV is written per-invoice above — nothing to do here


async def export_csv(all_states: list[dict]):
    """
    Automatically writes invoice_audit_log.csv after every orchestrator run.
    File is saved in the working directory — mounted to /app in Docker,
    which maps to your project folder on the host.
    """
    import csv
    import json as _json

    csv_path = "/app/invoice_audit_log.csv"
    # Also write locally if running outside Docker
    if not os.path.exists("/app"):
        csv_path = "invoice_audit_log.csv"

    file_exists = os.path.exists(csv_path)
    headers = [
        "Timestamp", "Invoice Number", "Scenario", "Vendor",
        "Total Amount", "Final State", "Decision",
        "Compliance Score", "Anomaly Flags", "Policy Violations",
        "Ledger ID", "Alert ID", "Error"
    ]

    rows_written = 0
    with open(csv_path, "a", newline="") as f:
        writer = csv.writer(f)
        if not file_exists:
            writer.writerow(headers)

        for state in all_states:
            from datetime import datetime
            now = datetime.now().strftime("%Y-%m-%d %H:%M:%S")

            inv = state.get("extracted_invoice") or {}
            if isinstance(inv, dict):
                vendor      = inv.get("vendor", {}).get("vendor_name", "Unknown")
                total       = inv.get("total_amount", 0)
                inv_num     = inv.get("invoice_number", state.get("invoice_number", "?"))
                scenario    = inv.get("scenario", "?")
            else:
                vendor, total = "Unknown", 0
                inv_num     = state.get("invoice_number", "?")
                scenario    = "?"

            val = state.get("validation_result") or {}
            if isinstance(val, dict):
                score       = val.get("compliance_score", "N/A")
                flags       = len(val.get("anomaly_flags", []))
                violations  = "; ".join(val.get("policy_violations", [])) or "None"
            else:
                score, flags, violations = "N/A", 0, "None"

            ledger  = state.get("ledger_response") or {}
            ledger_id = ledger.get("invoice_id", "") if isinstance(ledger, dict) else ""

            notif   = state.get("notification_response") or {}
            alert_id = notif.get("message_id", "") if isinstance(notif, dict) else ""

            orch_state = str(state.get("orchestrator_state", "?")).replace("OrchestratorState.", "")

            if ledger_id:
                decision = "APPROVED -> LEDGER"
            elif alert_id:
                decision = "FLAGGED -> ALERT SENT"
            else:
                err_msg = state.get("extraction_error") or state.get("validation_error") or ""
                decision = f"ERROR: {str(err_msg)[:50]}"

            error = str(
                state.get("extraction_error") or
                state.get("validation_error") or
                state.get("settlement_error") or ""
            )

            writer.writerow([
                now, inv_num, scenario, vendor, total,
                orch_state, decision, score, flags,
                violations, ledger_id, alert_id, error
            ])
            rows_written += 1

    log.info(f"\n{'═'*65}")
    log.info(f"  📄 CSV AUDIT LOG")
    log.info(f"  File    : {csv_path}")
    log.info(f"  Rows    : {rows_written} invoice(s) logged")
    log.info(f"{'═'*65}\n")


if __name__ == "__main__":
    asyncio.run(main())
