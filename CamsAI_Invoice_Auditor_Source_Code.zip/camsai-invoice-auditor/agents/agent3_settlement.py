"""
Agent 3: Reporting & Settlement
─────────────────────────────────
For COMPLIANT invoices:   calls API 4 (Ledger Write) → COMPLETE
For ANOMALOUS invoices:   calls API 5 (Notification/Alert) + Slack → COMPLETE
For ERROR state:          calls API 5 (error alert) + Slack → COMPLETE
"""
from __future__ import annotations

import logging
import os
from decimal import Decimal
from pathlib import Path

import httpx

import sys
sys.path.insert(0, str(Path(__file__).parent.parent))
from mock_data.schemas import (
    AnomalyFlag, GraphState, LedgerWriteRequest, LedgerWriteResponse,
    NotificationRequest, NotificationResponse, OrchestratorState
)

log = logging.getLogger("Agent3-Settlement")
MCP_URL           = os.getenv("MCP_URL", "http://localhost:8080")
ALERT_EMAIL       = os.getenv("ALERT_EMAIL", "test@example.com")
SLACK_WEBHOOK_URL = os.getenv("SLACK_WEBHOOK_URL", "")


# ── Slack Alert ───────────────────────────────────────────────────────────────

async def _send_slack_alert(
    invoice_number: str,
    vendor_name: str,
    total,
    flags: list,
    severity: str,
    orch_state: str
):
    """Send a real Slack message via webhook for anomalous/error invoices."""
    if not SLACK_WEBHOOK_URL:
        log.warning("[Agent3] SLACK_WEBHOOK_URL not set — skipping Slack alert")
        return

    severity_emoji = {
        "critical": "🚨",
        "high":     "⚠️",
        "medium":   "🔶",
        "low":      "🔵"
    }.get(severity, "⚠️")

    flags_text = "\n".join(
        f"• *{f.field}*: {f.reason} (_{f.severity}_)"
        for f in flags
    ) or "• No specific flags"

    message = {
        "text": f"{severity_emoji} *Invoice Anomaly Alert* — {invoice_number}",
        "blocks": [
            {
                "type": "header",
                "text": {
                    "type": "plain_text",
                    "text": f"{severity_emoji} Invoice Anomaly Detected — Action Required"
                }
            },
            {
                "type": "section",
                "fields": [
                    {"type": "mrkdwn", "text": f"*Invoice #*\n{invoice_number}"},
                    {"type": "mrkdwn", "text": f"*Vendor*\n{vendor_name}"},
                    {"type": "mrkdwn", "text": f"*Total Amount*\n${float(total):,.2f}"},
                    {"type": "mrkdwn", "text": f"*Severity*\n{severity.upper()}"},
                    {"type": "mrkdwn", "text": f"*State*\n{orch_state}"},
                    {"type": "mrkdwn", "text": f"*Flags*\n{len(flags)}"}
                ]
            },
            {
                "type": "section",
                "text": {
                    "type": "mrkdwn",
                    "text": f"*Anomaly Details:*\n{flags_text}"
                }
            },
            {"type": "divider"},
            {
                "type": "context",
                "elements": [
                    {
                        "type": "mrkdwn",
                        "text": "🤖 CamsAI Invoice Auditor — Automated Escalation Alert"
                    }
                ]
            }
        ]
    }

    try:
        async with httpx.AsyncClient(timeout=10) as client:
            r = await client.post(
                SLACK_WEBHOOK_URL,
                json=message,
                headers={"Content-Type": "application/json"}
            )
            if r.status_code == 200:
                log.info(f"[Agent3] ✅ Slack alert sent for {invoice_number}")
            else:
                log.warning(f"[Agent3] Slack returned {r.status_code}: {r.text}")
    except Exception as e:
        log.warning(f"[Agent3] Slack alert failed: {e}")


# ── Settlement sub-node ───────────────────────────────────────────────────────

async def settle_to_ledger(state: GraphState) -> GraphState:
    """LangGraph node: Ledger settlement — called when COMPLIANT."""
    invoice    = state.extracted_invoice
    validation = state.validation_result
    log.info(f"[Agent3] Writing to ledger: {invoice.invoice_number}")

    try:
        async with httpx.AsyncClient(timeout=20) as client:
            resp = await client.post(
                f"{MCP_URL}/api/v1/ledger/write",
                json=LedgerWriteRequest(
                    invoice            = invoice,
                    validation         = validation,
                    orchestrator_state = OrchestratorState.SETTLING
                ).model_dump(mode="json")
            )
            resp.raise_for_status()
            result = LedgerWriteResponse(**resp.json())

        state.ledger_response    = result
        state.orchestrator_state = OrchestratorState.COMPLETE
        log.info(f"[Agent3] ✓ Ledger write: {result.invoice_id} — {result.message}")

    except httpx.HTTPStatusError as e:
        err = f"API 4 (ledger) HTTP {e.response.status_code}: {e.response.text[:200]}"
        log.error(f"[Agent3] {err}")
        state.settlement_error   = err
        state.orchestrator_state = OrchestratorState.ERROR

    except httpx.RequestError as e:
        err = f"API 4 (ledger) connection error: {e}"
        log.error(f"[Agent3] {err}")
        state.settlement_error   = err
        state.orchestrator_state = OrchestratorState.ERROR

    except Exception as e:
        err = f"Unexpected settlement error: {type(e).__name__}: {e}"
        log.error(f"[Agent3] {err}")
        state.settlement_error   = err
        state.orchestrator_state = OrchestratorState.ERROR

    return state


# ── Alert sub-node ────────────────────────────────────────────────────────────

async def send_alert_notification(state: GraphState) -> GraphState:
    """
    LangGraph node: Alert/escalation — called when ANOMALOUS or ERROR.
    Sends alert via MCP API 5 AND posts to Slack webhook.
    """
    invoice    = state.extracted_invoice
    validation = state.validation_result

    # Determine severity
    if validation:
        severities = [f.severity for f in validation.anomaly_flags]
        if "critical" in severities:
            severity = "critical"
        elif "high" in severities:
            severity = "high"
        elif "medium" in severities:
            severity = "medium"
        else:
            severity = "low"
        flags = validation.anomaly_flags
    else:
        severity = "critical"
        flags = [AnomalyFlag(
            field    = "system",
            reason   = state.extraction_error or state.validation_error or "Unknown error",
            severity = "critical"
        )]

    vendor_name    = invoice.vendor.vendor_name if invoice else "Unknown Vendor"
    invoice_number = invoice.invoice_number if invoice else (state.invoice_number or "UNKNOWN")
    total          = invoice.total_amount if invoice else Decimal("0")
    orch_state     = str(state.orchestrator_state).replace("OrchestratorState.", "")

    log.warning(
        f"[Agent3] Sending alert for {invoice_number} — "
        f"severity: {severity} — flags: {len(flags)}"
    )

    # ── API 5: Email/log notification ─────────────────────────────────────────
    try:
        async with httpx.AsyncClient(timeout=20) as client:
            resp = await client.post(
                f"{MCP_URL}/api/v1/notify/alert",
                json=NotificationRequest(
                    invoice_number     = invoice_number,
                    vendor_name        = vendor_name,
                    total_amount       = total,
                    anomaly_flags      = flags,
                    severity           = severity,
                    recipient_email    = ALERT_EMAIL,
                    orchestrator_state = state.orchestrator_state
                ).model_dump(mode="json")
            )
            resp.raise_for_status()
            result = NotificationResponse(**resp.json())

        state.notification_response = result
        state.orchestrator_state    = OrchestratorState.COMPLETE
        log.info(f"[Agent3] ✓ Alert sent via {result.channel}: msg_id={result.message_id}")

    except httpx.RequestError as e:
        log.error(f"[Agent3] API 5 connection error: {e}")
        state.orchestrator_state = OrchestratorState.COMPLETE

    except Exception as e:
        log.error(f"[Agent3] Notification error: {e}")
        state.orchestrator_state = OrchestratorState.COMPLETE

    # ── Slack escalation (Scenario B + C + any anomaly) ───────────────────────
    await _send_slack_alert(
        invoice_number = invoice_number,
        vendor_name    = vendor_name,
        total          = total,
        flags          = flags,
        severity       = severity,
        orch_state     = orch_state
    )

    return state
