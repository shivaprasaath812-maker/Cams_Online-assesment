"""
Agent 2: Validation & Compliance
──────────────────────────────────
Calls API 2 (Vector Knowledge — ChromaDB) to retrieve vendor contracts,
then calls API 3 (Policy Check) to run deterministic compliance rules.

State transitions:
  VALIDATING → COMPLIANT   (all rules pass)
  VALIDATING → ANOMALOUS   (flags detected)
  VALIDATING → ERROR       (agent crash)
"""
from __future__ import annotations

import logging
import os
from pathlib import Path

import httpx
from pydantic import ValidationError

import sys
sys.path.insert(0, str(Path(__file__).parent.parent))
from mock_data.schemas import (
    AnomalyFlag, GraphState, OrchestratorState, ValidationResult
)

log = logging.getLogger("Agent2-Validation")
MCP_URL = os.getenv("MCP_URL", "http://localhost:8080")


# ──────────────────────────────────────────────────────────────────────────────
# Main node function
# ──────────────────────────────────────────────────────────────────────────────

async def validate_and_check_compliance(state: GraphState) -> GraphState:
    """
    LangGraph node: Agent 2
    1. Query API 2 (ChromaDB) for matching vendor contracts
    2. Run API 3 (Policy Check) with invoice + contracts
    3. Route state to COMPLIANT or ANOMALOUS
    """
    invoice = state.extracted_invoice
    if invoice is None:
        state.validation_error = "No extracted invoice in state — Agent 1 may have failed"
        state.orchestrator_state = OrchestratorState.ERROR
        return state

    log.info(f"[Agent2] Validating: {invoice.invoice_number} — vendor: {invoice.vendor.vendor_id}")

    # ── Step 1: Vector query (API 2) ──────────────────────────────────────────
    contracts = []
    try:
        categories = list({item.category for item in invoice.line_items})
        async with httpx.AsyncClient(timeout=15) as client:
            resp = await client.post(
                f"{MCP_URL}/api/v1/vector/query",
                json={
                    "vendor_id":          invoice.vendor.vendor_id,
                    "vendor_name":        invoice.vendor.vendor_name,
                    "service_categories": categories,
                    "n_results":          3
                }
            )
            resp.raise_for_status()
            vector_data = resp.json()
            contracts   = vector_data.get("contracts", [])
            log.info(f"[Agent2] Vector query → {len(contracts)} contract(s) retrieved")

    except httpx.RequestError as e:
        log.warning(f"[Agent2] API 2 (vector) unreachable: {e} — proceeding with defaults")
    except Exception as e:
        log.warning(f"[Agent2] API 2 unexpected error: {e} — proceeding with defaults")

    # ── Step 2: Policy check (API 3) ──────────────────────────────────────────
    try:
        async with httpx.AsyncClient(timeout=15) as client:
            resp = await client.post(
                f"{MCP_URL}/api/v1/policy/check",
                json={
                    "invoice":   invoice.model_dump(mode="json"),
                    "contracts": contracts
                }
            )
            resp.raise_for_status()
            policy_data = resp.json()

        # Parse response into ValidationResult
        anomaly_flags = [
            AnomalyFlag(
                field    = f.get("field", "unknown"),
                reason   = f.get("reason", ""),
                severity = f.get("severity", "medium"),
                value    = f.get("value")
            )
            for f in policy_data.get("anomaly_flags", [])
        ]

        validation = ValidationResult(
            passed             = policy_data.get("passed", False),
            compliance_score   = float(policy_data.get("compliance_score", 0.0)),
            anomaly_flags      = anomaly_flags,
            policy_violations  = policy_data.get("policy_violations", []),
            vector_match_score = policy_data.get("vector_match_score"),
            recommendation     = policy_data.get("recommendation", "")
        )

        state.validation_result = validation

        if validation.passed:
            state.orchestrator_state = OrchestratorState.COMPLIANT
            log.info(
                f"[Agent2] ✓ COMPLIANT — score: {validation.compliance_score:.1f} "
                f"vector_match: {validation.vector_match_score}"
            )
        else:
            state.orchestrator_state = OrchestratorState.ANOMALOUS
            log.warning(
                f"[Agent2] ⚠ ANOMALOUS — score: {validation.compliance_score:.1f} "
                f"flags: {len(validation.anomaly_flags)} "
                f"violations: {validation.policy_violations}"
            )

    except httpx.HTTPStatusError as e:
        err = f"API 3 (policy) HTTP {e.response.status_code}: {e.response.text[:200]}"
        log.error(f"[Agent2] {err}")
        state.validation_error = err
        state.orchestrator_state = OrchestratorState.ERROR

    except httpx.RequestError as e:
        err = f"API 3 (policy) connection error: {e}"
        log.error(f"[Agent2] {err}")
        state.validation_error = err
        state.orchestrator_state = OrchestratorState.ERROR

    except Exception as e:
        err = f"Unexpected validation error: {type(e).__name__}: {e}"
        log.error(f"[Agent2] {err}")
        state.validation_error = err
        state.orchestrator_state = OrchestratorState.ERROR

    return state
